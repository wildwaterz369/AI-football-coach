import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { subscriptionAPI } from '../services/api';
import { Plan, SubscriptionStatus } from '../types';
import Loading from '../components/Loading';
import Error from '../components/Error';
import {
  Check,
  Crown,
  Zap,
  Shield,
  CreditCard,
  Wallet,
  AlertCircle,
  CheckCircle2,
  XCircle,
  ArrowLeft,
  Sparkles
} from 'lucide-react';

const planIcons: Record<string, typeof Crown> = {
  free: Zap,
  pro: Crown,
  elite: Shield,
};

const planColors: Record<string, string> = {
  free: 'bg-gray-100 text-gray-700 border-gray-200',
  pro: 'bg-brand-50 text-brand-700 border-brand-200',
  elite: 'bg-amber-50 text-amber-700 border-amber-200',
};

const planBadgeColors: Record<string, string> = {
  free: 'bg-gray-100 text-gray-600',
  pro: 'bg-brand-100 text-brand-700',
  elite: 'bg-amber-100 text-amber-700',
};

export default function SubscriptionPage() {
  const navigate = useNavigate();
  const { subscription, refreshSubscription } = useAuth();
  const [plans, setPlans] = useState<Plan[]>([]);
  const [loadingPlans, setLoadingPlans] = useState(false);
  const [loadingAction, setLoadingAction] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<'stripe' | 'alipay'>('stripe');

  useEffect(() => {
    loadPlans();
  }, []);

  const loadPlans = async () => {
    setLoadingPlans(true);
    try {
      const { data } = await subscriptionAPI.plans();
      setPlans(data.plans || []);
    } catch (err: any) {
      setError('Failed to load plans. Please try again.');
    } finally {
      setLoadingPlans(false);
    }
  };

  const handleSubscribe = async (planId: string) => {
    if (planId === subscription?.current_plan?.id) return;
    setLoadingAction(true);
    setError('');
    setSuccess('');

    try {
      if (paymentMethod === 'stripe') {
        const { data } = await subscriptionAPI.createStripeCheckout(planId);
        // In a real app with Stripe.js loaded, you'd redirect to checkout
        // For now, we show a success message with the payment intent details
        setSuccess(`${data.message} — Payment intent created: ${data.payment_intent_id}`);
        await refreshSubscription();
      } else {
        const { data } = await subscriptionAPI.createAlipayOrder(planId);
        setSuccess(`${data.message} — Order created: ${data.order_id}`);
        await refreshSubscription();
      }
    } catch (err: any) {
      const detail = err.response?.data?.detail || 'Subscription failed. Please try again.';
      setError(detail);
    } finally {
      setLoadingAction(false);
      setSelectedPlan(null);
    }
  };

  const handleCancel = async () => {
    if (!confirm('Are you sure you want to cancel your subscription? You will keep access until the end of your current billing period.')) return;
    setLoadingAction(true);
    try {
      const { data } = await subscriptionAPI.cancel();
      setSuccess(data.message);
      await refreshSubscription();
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to cancel subscription.');
    } finally {
      setLoadingAction(false);
    }
  };

  const handleResume = async () => {
    setLoadingAction(true);
    try {
      const { data } = await subscriptionAPI.resume();
      setSuccess(data.message);
      await refreshSubscription();
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to resume subscription.');
    } finally {
      setLoadingAction(false);
    }
  };

  const isCurrentPlan = (planId: string) =>
    subscription?.current_plan?.id === planId &&
    subscription?.active_subscription?.status === 'active';

  const isDowngrade = (planId: string) => {
    const order = ['free', 'pro', 'elite'];
    const currentIdx = order.indexOf(subscription?.current_plan?.id || 'free');
    const targetIdx = order.indexOf(planId);
    return targetIdx < currentIdx;
  };

  if (!subscription && !loadingPlans) {
    return <Error retry={loadPlans} backTo="/dashboard" />;
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <button
        onClick={() => navigate(-1)}
        className="flex items-center gap-2 text-sm text-gray-500 hover:text-gray-700 mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        Back
      </button>

      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
          <Sparkles className="w-6 h-6 text-brand-600" />
          Subscription & Plans
        </h1>
        <p className="text-gray-600 mt-1">Manage your plan, billing, and analysis quotas</p>
      </div>

      {/* Status alerts */}
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-100 rounded-xl flex items-center gap-3">
          <XCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
          <p className="text-sm text-red-700">{error}</p>
        </div>
      )}
      {success && (
        <div className="mb-6 p-4 bg-green-50 border border-green-100 rounded-xl flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
          <p className="text-sm text-green-700">{success}</p>
        </div>
      )}

      {/* Current Plan Card */}
      <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-6 mb-8">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h2 className="text-lg font-semibold text-gray-900">Current Plan</h2>
            <p className="text-sm text-gray-500 mt-1">
              {subscription?.active_subscription?.status === 'active'
                ? 'Your subscription is active and renews automatically.'
                : subscription?.active_subscription?.status === 'cancelled'
                ? 'Your subscription will remain active until the end of the current billing period.'
                : 'You are on the free plan with limited features.'}
            </p>
          </div>
          <span className={`px-3 py-1 rounded-full text-xs font-semibold ${planBadgeColors[subscription?.current_plan?.id || 'free']}`}>
            {subscription?.current_plan?.name}
          </span>
        </div>

        {/* Quota usage */}
        <div className="mt-4">
          <div className="flex items-center justify-between text-sm mb-2">
            <span className="text-gray-600">Analysis Quota Used</span>
            <span className={`font-medium ${
              subscription?.has_quota ? 'text-gray-900' : 'text-red-600'
            }`}>
              {subscription?.analysis_used} / {subscription?.analysis_quota}
            </span>
          </div>
          <div className="w-full h-2.5 bg-gray-100 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                (subscription?.percent_used || 0) > 90
                  ? 'bg-red-500'
                  : (subscription?.percent_used || 0) > 70
                  ? 'bg-amber-500'
                  : 'bg-brand-500'
              }`}
              style={{ width: `${Math.min(subscription?.percent_used || 0, 100)}%` }}
            />
          </div>
          {!subscription?.has_quota && (
            <div className="mt-2 flex items-center gap-2 text-sm text-red-600">
              <AlertCircle className="w-4 h-4" />
              You have reached your monthly analysis quota. Upgrade to continue analyzing videos.
            </div>
          )}
          {(subscription?.percent_used || 0) > 70 && subscription?.has_quota && (
            <div className="mt-2 flex items-center gap-2 text-sm text-amber-600">
              <AlertCircle className="w-4 h-4" />
              You are approaching your monthly analysis limit.
            </div>
          )}
        </div>

        {/* Subscription actions */}
        {subscription?.active_subscription && subscription.active_subscription.status === 'active' && (
          <div className="mt-6 flex gap-3">
            <button
              onClick={handleCancel}
              disabled={loadingAction}
              className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-50 disabled:opacity-50"
            >
              Cancel Subscription
            </button>
          </div>
        )}
        {subscription?.active_subscription && subscription.active_subscription.status === 'cancelled' && (
          <div className="mt-6 flex gap-3">
            <button
              onClick={handleResume}
              disabled={loadingAction}
              className="px-4 py-2 bg-brand-600 text-white rounded-lg text-sm font-medium hover:bg-brand-700 disabled:opacity-50"
            >
              Resume Subscription
            </button>
          </div>
        )}
      </div>

      {/* Plan Comparison */}
      <h2 className="text-lg font-semibold text-gray-900 mb-4">Choose a Plan</h2>
      {loadingPlans ? (
        <Loading message="Loading plans..." />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {plans.map((plan) => {
            const Icon = planIcons[plan.id] || Zap;
            const isActive = isCurrentPlan(plan.id);
            const isDown = isDowngrade(plan.id);
            const isSelected = selectedPlan === plan.id;

            return (
              <div
                key={plan.id}
                className={`relative rounded-xl border-2 p-6 transition-all ${
                  isActive
                    ? 'border-brand-500 bg-brand-50/30'
                    : isSelected
                    ? 'border-brand-400 bg-brand-50/20'
                    : 'border-gray-200 bg-white hover:border-gray-300'
                }`}
              >
                {isActive && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <span className="px-3 py-1 bg-brand-600 text-white text-xs font-semibold rounded-full">
                      Current Plan
                    </span>
                  </div>
                )}

                <div className="flex items-center gap-3 mb-4">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${planColors[plan.id]}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{plan.name}</h3>
                    <p className="text-sm text-gray-500">
                      {plan.price_monthly_cny === 0
                        ? 'Free forever'
                        : `¥${plan.price_monthly_cny}/month`}
                    </p>
                  </div>
                </div>

                <div className="mb-6">
                  <p className="text-sm font-medium text-gray-700 mb-2">
                    {plan.analysis_quota === 9999
                      ? 'Unlimited AI analyses'
                      : `${plan.analysis_quota} AI analyses per month`}
                  </p>
                  <ul className="space-y-2">
                    {plan.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-sm text-gray-600">
                        <Check className="w-4 h-4 text-brand-600 flex-shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {!isActive && (
                  <>
                    {isSelected ? (
                      <div className="space-y-3">
                        <div className="flex gap-2">
                          <button
                            onClick={() => setPaymentMethod('stripe')}
                            className={`flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                              paymentMethod === 'stripe'
                                ? 'bg-brand-600 text-white'
                                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                            }`}
                          >
                            <CreditCard className="w-4 h-4" />
                            Card
                          </button>
                          <button
                            onClick={() => setPaymentMethod('alipay')}
                            className={`flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                              paymentMethod === 'alipay'
                                ? 'bg-brand-600 text-white'
                                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                            }`}
                          >
                            <Wallet className="w-4 h-4" />
                            Alipay
                          </button>
                        </div>
                        <div className="flex gap-2">
                          <button
                            onClick={() => setSelectedPlan(null)}
                            className="flex-1 px-3 py-2 border border-gray-300 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-50"
                          >
                            Cancel
                          </button>
                          <button
                            onClick={() => handleSubscribe(plan.id)}
                            disabled={loadingAction}
                            className={`flex-1 px-3 py-2 rounded-lg text-sm font-medium text-white disabled:opacity-50 ${
                              isDown ? 'bg-gray-600 hover:bg-gray-700' : 'bg-brand-600 hover:bg-brand-700'
                            }`}
                          >
                            {loadingAction ? 'Processing...' : isDown ? 'Downgrade' : 'Subscribe'}
                          </button>
                        </div>
                      </div>
                    ) : (
                      <button
                        onClick={() => { setSelectedPlan(plan.id); setError(''); setSuccess(''); }}
                        className="w-full py-2.5 border-2 border-gray-200 text-gray-700 rounded-lg text-sm font-medium hover:border-brand-500 hover:text-brand-700 transition-colors"
                      >
                        {isDown ? 'Select Plan' : 'Upgrade'}
                      </button>
                    )}
                  </>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
