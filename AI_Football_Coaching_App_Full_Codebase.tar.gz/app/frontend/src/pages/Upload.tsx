import { useState, useCallback, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { Upload, Camera, X, FileVideo, CheckCircle, AlertCircle, Users, Crown, AlertTriangle } from 'lucide-react';
import { sessionAPI, playerAPI } from '../services/api';
import { PlayerWithStats } from '../types';

export default function UploadPage() {
  const navigate = useNavigate();
  const { subscription } = useAuth();
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [error, setError] = useState('');
  const [dragActive, setDragActive] = useState(false);
  const [players, setPlayers] = useState<PlayerWithStats[]>([]);
  const [loadingPlayers, setLoadingPlayers] = useState(false);
  const [selectedPlayer, setSelectedPlayer] = useState<number | ''>('');

  const quotaExceeded = subscription && !subscription.has_quota;
  const quotaWarning = subscription && subscription.has_quota && (subscription.percent_used || 0) > 70;
  const quotaNearFull = subscription && subscription.has_quota && (subscription.percent_used || 0) > 90;

  useEffect(() => {
    loadPlayers();
  }, []);

  const loadPlayers = async () => {
    setLoadingPlayers(true);
    try {
      const res = await playerAPI.list();
      setPlayers(res.data);
    } catch (err) {
      console.error('Failed to load players:', err);
    } finally {
      setLoadingPlayers(false);
    }
  };

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    const droppedFile = e.dataTransfer.files?.[0];
    if (droppedFile && droppedFile.type.startsWith('video/')) {
      setFile(droppedFile);
      setError('');
    } else {
      setError('Please upload a valid video file');
    }
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile && selectedFile.type.startsWith('video/')) {
      setFile(selectedFile);
      setError('');
    } else {
      setError('Please upload a valid video file');
    }
  };

  const handleUpload = async () => {
    if (!file || !title.trim()) {
      setError('Please provide a title and select a video file');
      return;
    }

    setIsUploading(true);
    setUploadProgress(0);
    setError('');

    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('title', title.trim());
      formData.append('description', description.trim());
      if (selectedPlayer) formData.append('player_id', String(selectedPlayer));

      const res = await sessionAPI.upload(formData, (progress) => {
        setUploadProgress(progress);
      });

      navigate('/analysis');
    } catch (err: any) {
      const detail = err.response?.data?.detail || 'Upload failed. Please try again.';
      const status = err.response?.status;
      if (status === 402) {
        setError('Your monthly analysis quota has been reached. Please upgrade your plan to continue uploading.');
      } else {
        setError(detail);
      }
      setIsUploading(false);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Upload Video</h1>
        <p className="text-gray-600 mt-1">Upload a training or match video for AI analysis</p>
      </div>

      {/* Quota Alerts */}
      {quotaExceeded && (
        <div className="mb-6 p-4 bg-red-50 border border-red-100 rounded-xl flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-red-800">Analysis Quota Exceeded</p>
            <p className="text-sm text-red-600 mt-1">
              You have used all {subscription?.analysis_quota} analyses this month.{' '}
              <Link to="/subscription" className="font-medium underline hover:text-red-700">
                Upgrade your plan
              </Link>{' '}
              to continue analyzing videos.
            </p>
          </div>
        </div>
      )}
      {!quotaExceeded && quotaNearFull && (
        <div className="mb-6 p-4 bg-amber-50 border border-amber-100 rounded-xl flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-amber-800">Quota Almost Full</p>
            <p className="text-sm text-amber-600 mt-1">
              You have used {subscription?.analysis_used} of {subscription?.analysis_quota} analyses this month.{' '}
              <Link to="/subscription" className="font-medium underline hover:text-amber-700">
                Consider upgrading
              </Link>{' '}
              for more.
            </p>
          </div>
        </div>
      )}
      {!quotaExceeded && !quotaNearFull && quotaWarning && (
        <div className="mb-6 p-4 bg-blue-50 border border-blue-100 rounded-xl flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-blue-800">Quota Running Low</p>
            <p className="text-sm text-blue-600 mt-1">
              You have used {subscription?.analysis_used} of {subscription?.analysis_quota} analyses this month.
            </p>
          </div>
        </div>
      )}

      <div className="bg-white rounded-xl p-6 border border-gray-100 shadow-sm space-y-6">
        {error && (
          <div className="flex items-center gap-2 p-3 bg-red-50 text-red-700 rounded-lg text-sm">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Session Title *
          </label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g., Tuesday Training - Passing Drills"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Assign Player
          </label>
          <div className="relative">
            <Users className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <select
              value={selectedPlayer}
              onChange={(e) => setSelectedPlayer(e.target.value ? Number(e.target.value) : '')}
              disabled={loadingPlayers}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent appearance-none bg-white disabled:opacity-50"
            >
              <option value="">No player assigned</option>
              {players.map((player) => (
                <option key={player.id} value={player.id}>
                  {player.name} {player.position ? `(${player.position})` : ''}
                </option>
              ))}
            </select>
          </div>
          <p className="text-xs text-gray-500 mt-1">
            Select a player to link this video to their profile.
          </p>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Description (optional)
          </label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe the session, drills performed, or any notes..."
            rows={3}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent resize-none"
          />
        </div>

        {!file ? (
          <div
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-xl p-8 text-center transition-colors ${
              quotaExceeded
                ? 'border-gray-200 bg-gray-50 opacity-60 cursor-not-allowed'
                : dragActive
                ? 'border-brand-500 bg-brand-50'
                : 'border-gray-300 hover:border-gray-400'
            }`}
          >
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Upload className="w-8 h-8 text-gray-400" />
            </div>
            <p className="text-gray-700 font-medium mb-1">
              {quotaExceeded ? 'Quota exceeded — Upgrade to upload' : 'Drag and drop your video here'}
            </p>
            <p className="text-sm text-gray-500 mb-4">
              {quotaExceeded ? 'Subscribe to a paid plan to continue' : 'or click to browse files'}
            </p>
            <input
              type="file"
              accept="video/*"
              onChange={handleFileChange}
              className="hidden"
              id="video-upload"
              disabled={quotaExceeded}
            />
            <label
              htmlFor="video-upload"
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg cursor-pointer transition-colors ${
                quotaExceeded
                  ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  : 'bg-brand-600 text-white hover:bg-brand-700'
              }`}
            >
              {quotaExceeded ? (
                <>
                  <Crown className="w-4 h-4" />
                  Upgrade Plan
                </>
              ) : (
                <>
                  <Camera className="w-4 h-4" />
                  Choose Video
                </>
              )}
            </label>
            <p className="text-xs text-gray-400 mt-3">
              Supports MP4, MOV, AVI, MKV up to 2GB
            </p>
          </div>
        ) : (
          <div className="border rounded-xl p-4 bg-gray-50">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-brand-100 rounded-lg flex items-center justify-center">
                <FileVideo className="w-5 h-5 text-brand-600" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate">{file.name}</p>
                <p className="text-xs text-gray-500">{formatFileSize(file.size)}</p>
              </div>
              <button
                onClick={() => setFile(null)}
                className="p-1 hover:bg-gray-200 rounded transition-colors"
              >
                <X className="w-4 h-4 text-gray-500" />
              </button>
            </div>
          </div>
        )}

        {isUploading && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600">Uploading...</span>
              <span className="text-gray-600">{uploadProgress}%</span>
            </div>
            <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-brand-500 rounded-full transition-all duration-300"
                style={{ width: `${uploadProgress}%` }}
              />
            </div>
          </div>
        )}

        <button
          onClick={handleUpload}
          disabled={isUploading || !file || !title.trim() || quotaExceeded}
          className="w-full py-2.5 bg-brand-600 text-white rounded-lg font-medium hover:bg-brand-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          {isUploading ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              Uploading...
            </>
          ) : (
            <>
              <CheckCircle className="w-4 h-4" />
              Upload and Analyze
            </>
          )}
        </button>
      </div>
    </div>
  );
}
