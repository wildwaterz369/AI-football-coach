import { useState } from 'react';
import { Dumbbell, ChevronRight, Star, Clock, Users, Target, Filter, Search } from 'lucide-react';

interface Drill {
  id: number;
  title: string;
  category: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  duration: string;
  players: string;
  description: string;
  focus: string[];
  rating: number;
}

const drills: Drill[] = [
  {
    id: 1,
    title: 'Rondo 4v1 + 1',
    category: 'Passing',
    difficulty: 'Intermediate',
    duration: '15 min',
    players: '6-8',
    description: 'Classic possession drill with a neutral player. Players in the middle try to win the ball back.',
    focus: ['Passing', 'First Touch', 'Vision'],
    rating: 4.8,
  },
  {
    id: 2,
    title: '1v1 Attacking Duels',
    category: 'Dribbling',
    difficulty: 'Beginner',
    duration: '20 min',
    players: '4-6',
    description: 'Attacker vs defender duels focusing on beating the defender and finishing.',
    focus: ['Dribbling', 'Finishing', 'Defending'],
    rating: 4.5,
  },
  {
    id: 3,
    title: 'High-Intensity Sprint Intervals',
    category: 'Physical',
    difficulty: 'Advanced',
    duration: '25 min',
    players: 'Full team',
    description: 'Sprint conditioning with recovery periods. Builds anaerobic capacity.',
    focus: ['Speed', 'Conditioning', 'Recovery'],
    rating: 4.7,
  },
  {
    id: 4,
    title: 'Positional Pressing Game',
    category: 'Tactical',
    difficulty: 'Advanced',
    duration: '30 min',
    players: 'Full team',
    description: 'Small-sided game focused on pressing triggers and coordinated defensive shape.',
    focus: ['Pressing', 'Team Shape', 'Transitions'],
    rating: 4.9,
  },
  {
    id: 5,
    title: 'Passing Gates',
    category: 'Passing',
    difficulty: 'Beginner',
    duration: '15 min',
    players: '4-6',
    description: 'Pass through gates to a teammate. Focus on weight and accuracy of passes.',
    focus: ['Passing Accuracy', 'Weight', 'Angles'],
    rating: 4.3,
  },
  {
    id: 6,
    title: 'Shooting from Cutbacks',
    category: 'Finishing',
    difficulty: 'Intermediate',
    duration: '20 min',
    players: '6-8',
    description: 'Wingers cut the ball back for attackers to finish first-time.',
    focus: ['Finishing', 'Movement', 'Crossing'],
    rating: 4.6,
  },
  {
    id: 7,
    title: 'Counter-Attack Simulation',
    category: 'Tactical',
    difficulty: 'Intermediate',
    duration: '25 min',
    players: '8-10',
    description: 'Practice quick transitions from defense to attack with numerical advantages.',
    focus: ['Transitions', 'Decision Making', 'Speed'],
    rating: 4.8,
  },
  {
    id: 8,
    title: 'Juggling Progression',
    category: 'Technique',
    difficulty: 'Beginner',
    duration: '10 min',
    players: 'Individual',
    description: 'Ball juggling to improve touch and control. Progress from feet to thighs to head.',
    focus: ['Ball Control', 'Coordination', 'Confidence'],
    rating: 4.2,
  },
];

const categories = ['All', 'Passing', 'Dribbling', 'Physical', 'Tactical', 'Finishing', 'Technique'];
const difficulties = ['All', 'Beginner', 'Intermediate', 'Advanced'];

export default function Drills() {
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [difficultyFilter, setDifficultyFilter] = useState('All');
  const [search, setSearch] = useState('');
  const [selectedDrill, setSelectedDrill] = useState<Drill | null>(null);

  const filtered = drills.filter(d => {
    const matchesCategory = categoryFilter === 'All' || d.category === categoryFilter;
    const matchesDifficulty = difficultyFilter === 'All' || d.difficulty === difficultyFilter;
    const matchesSearch = d.title.toLowerCase().includes(search.toLowerCase()) ||
                          d.description.toLowerCase().includes(search.toLowerCase());
    return matchesCategory && matchesDifficulty && matchesSearch;
  });

  const getDifficultyColor = (d: string) => {
    if (d === 'Beginner') return 'bg-green-50 text-green-700';
    if (d === 'Intermediate') return 'bg-yellow-50 text-yellow-700';
    return 'bg-red-50 text-red-700';
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Drill Library</h1>
        <p className="text-gray-600 mt-1">Curated training drills for every aspect of the game</p>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search drills..."
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent"
          />
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setCategoryFilter(cat)}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
              categoryFilter === cat
                ? 'bg-brand-50 text-brand-700 border border-brand-200'
                : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="flex flex-wrap gap-2">
        {difficulties.map(diff => (
          <button
            key={diff}
            onClick={() => setDifficultyFilter(diff)}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
              difficultyFilter === diff
                ? 'bg-brand-50 text-brand-700 border border-brand-200'
                : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
            }`}
          >
            {diff}
          </button>
        ))}
      </div>

      {selectedDrill ? (
        <div className="bg-white rounded-xl p-6 border border-gray-100 shadow-sm">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h2 className="text-xl font-bold text-gray-900">{selectedDrill.title}</h2>
              <div className="flex items-center gap-3 mt-2">
                <span className={`px-2 py-1 rounded-lg text-xs font-medium ${getDifficultyColor(selectedDrill.difficulty)}`}>
                  {selectedDrill.difficulty}
                </span>
                <span className="text-sm text-gray-500">{selectedDrill.category}</span>
              </div>
            </div>
            <button
              onClick={() => setSelectedDrill(null)}
              className="text-sm text-gray-500 hover:text-gray-700"
            >
              Back to list
            </button>
          </div>

          <p className="text-gray-600 mb-6">{selectedDrill.description}</p>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="text-center p-3 bg-gray-50 rounded-lg">
              <Clock className="w-5 h-5 text-gray-400 mx-auto mb-1" />
              <div className="text-sm font-medium text-gray-900">{selectedDrill.duration}</div>
              <div className="text-xs text-gray-500">Duration</div>
            </div>
            <div className="text-center p-3 bg-gray-50 rounded-lg">
              <Users className="w-5 h-5 text-gray-400 mx-auto mb-1" />
              <div className="text-sm font-medium text-gray-900">{selectedDrill.players}</div>
              <div className="text-xs text-gray-500">Players</div>
            </div>
            <div className="text-center p-3 bg-gray-50 rounded-lg">
              <Star className="w-5 h-5 text-yellow-400 mx-auto mb-1" />
              <div className="text-sm font-medium text-gray-900">{selectedDrill.rating}</div>
              <div className="text-xs text-gray-500">Rating</div>
            </div>
            <div className="text-center p-3 bg-gray-50 rounded-lg">
              <Target className="w-5 h-5 text-gray-400 mx-auto mb-1" />
              <div className="text-sm font-medium text-gray-900">{selectedDrill.focus.length}</div>
              <div className="text-xs text-gray-500">Focus Areas</div>
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-gray-900 mb-2">Focus Areas</h3>
            <div className="flex flex-wrap gap-2">
              {selectedDrill.focus.map(f => (
                <span key={f} className="px-3 py-1 bg-brand-50 text-brand-700 rounded-lg text-sm font-medium">
                  {f}
                </span>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map(drill => (
            <button
              key={drill.id}
              onClick={() => setSelectedDrill(drill)}
              className="text-left bg-white rounded-xl p-5 border border-gray-100 shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 bg-brand-50 rounded-lg flex items-center justify-center">
                  <Dumbbell className="w-5 h-5 text-brand-600" />
                </div>
                <span className={`px-2 py-0.5 rounded text-xs font-medium ${getDifficultyColor(drill.difficulty)}`}>
                  {drill.difficulty}
                </span>
              </div>
              <h3 className="font-semibold text-gray-900 mb-1">{drill.title}</h3>
              <p className="text-sm text-gray-500 mb-3 line-clamp-2">{drill.description}</p>
              <div className="flex items-center gap-3 text-xs text-gray-400">
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {drill.duration}
                </span>
                <span className="flex items-center gap-1">
                  <Users className="w-3 h-3" />
                  {drill.players}
                </span>
                <span className="flex items-center gap-1">
                  <Star className="w-3 h-3" />
                  {drill.rating}
                </span>
              </div>
              <div className="flex items-center gap-1 mt-3 text-sm text-brand-600 font-medium">
                View details
                <ChevronRight className="w-4 h-4" />
              </div>
            </button>
          ))}
        </div>
      )}

      {filtered.length === 0 && !selectedDrill && (
        <div className="bg-white rounded-xl p-12 border border-gray-100 text-center">
          <Dumbbell className="w-12 h-12 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500">No drills match your filters</p>
        </div>
      )}
    </div>
  );
}
