import { useEffect, useState, useRef } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Play, Pause, Clock, User, BarChart3, Zap, Target, Activity, Shield, AlertCircle, Loader, CheckCircle, RotateCcw, FileText, ChevronLeft, ChevronRight, Users, Save } from 'lucide-react';
import { sessionAPI, playerAPI } from '../services/api';
import { SessionWithAnalysis, PlayerWithStats } from '../types';
import RadarChart from '../components/RadarChart';
import KeyMoments from '../components/KeyMoments';
import FieldVisualization from '../components/FieldVisualization';

export default function AnalysisDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [session, setSession] = useState<SessionWithAnalysis | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [activeMetric, setActiveMetric] = useState<'heatmap' | 'speed' | 'passes' | 'pressure'>('heatmap');
  const [players, setPlayers] = useState<PlayerWithStats[]>([]);
  const [selectedPlayer, setSelectedPlayer] = useState<number | ''>('');
  const [assigningPlayer, setAssigningPlayer] = useState(false);
  const [loadingPlayers, setLoadingPlayers] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const progressRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (id) {
      loadSession();
      loadPlayers();
    }
  }, [id]);

  const loadSession = async () => {
    try {
      const res = await sessionAPI.get(Number(id));
      setSession(res.data);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to load session');
    } finally {
      setLoading(false);
    }
  };

  const loadPlayers = async () => {
    setLoadingPlayers(true);
    try {
      const res = await playerAPI.list();
      const sorted = res.data.sort((a: PlayerWithStats, b: PlayerWithStats) => a.name.localeCompare(b.name));
      setPlayers(sorted);
    } catch (err) {
      console.error('Failed to load players:', err);
    } finally {
      setLoadingPlayers(false);
    }
  };

  const handleAssignPlayer = async () => {
    if (!selectedPlayer || !session) return;
    setAssigningPlayer(true);
    try {
      await sessionAPI.update(session.id, { player_id: selectedPlayer });
      await loadSession();
    } catch (err) {
      setError('Failed to assign player');
    } finally {
      setAssigningPlayer(false);
    }
  };

  const handleDelete = async () => {
    if (!confirm('Are you sure you want to delete this session?')) return;
    try {
      await sessionAPI.delete(Number(id));
      navigate('/analysis');
    } catch (err) {
      setError('Failed to delete session');
    }
  };

  const handleReanalyze = async () => {
    try {
      await sessionAPI.reanalyze(Number(id));
      loadSession();
    } catch (err) {
      setError('Failed to reanalyze session');
    }
  };

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
    }
  };

  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (progressRef.current && videoRef.current) {
      const rect = progressRef.current.getBoundingClientRect();
      const pos = (e.clientX - rect.left) / rect.width;
      videoRef.current.currentTime = pos * videoRef.current.duration;
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${String(secs).padStart(2, '0')}`;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (error || !session) {
    return (
      <div className="text-center py-12">
        <AlertCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
        <p className="text-gray-500">{error || 'Session not found'}</p>
        <Link to="/analysis" className="text-brand-600 hover:text-brand-700 mt-2 inline-block">
          Back to analysis
        </Link>
      </div>
    );
  }

  const analysis = session.analysis;
  const isProcessing = session.status === 'processing' || session.status === 'pending';
  const isCompleted = session.status === 'completed';
  const videoUrl = `${import.meta.env.VITE_API_URL}/uploads/videos/${session.video_path}`;
  const thumbnailUrl = session.thumbnail_path 
    ? `${import.meta.env.VITE_API_URL}/uploads/thumbnails/${session.thumbnail_path}`
    : null;

  const radarScores = analysis ? {
    dribbling: analysis.dribbling_score,
    passing: analysis.passing_score,
    shooting: analysis.shooting_score,
    positioning: analysis.positioning_score,
    physical: analysis.physical_score,
    overall: analysis.overall_score,
  } : null;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Link to="/analysis" className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
          <ArrowLeft className="w-5 h-5 text-gray-600" />
        </Link>
        <div className="flex-1">
          <h1 className="text-2xl font-bold text-gray-900">{session.title}</h1>
          <div className="flex items-center gap-3 mt-1">
            <span className={`text-sm px-2 py-0.5 rounded-full font-medium ${
              session.status === 'completed' ? 'bg-green-50 text-green-700' :
              session.status === 'processing' ? 'bg-blue-50 text-blue-700' :
              session.status === 'failed' ? 'bg-red-50 text-red-700' :
              'bg-yellow-50 text-yellow-700'
            }`}>
              {session.status === 'completed' && <CheckCircle className="w-3 h-3 inline mr-1" />}
              {session.status === 'processing' && <Loader className="w-3 h-3 inline mr-1 animate-spin" />}
              {session.status === 'failed' && <AlertCircle className="w-3 h-3 inline mr-1" />}
              {session.status}
            </span>
            <span className="text-sm text-gray-500">
              <Clock className="w-3 h-3 inline mr-1" />
              {formatTime(session.duration_seconds)}
            </span>
            {session.player_name ? (
              <span className="text-sm text-gray-500">
                <User className="w-3 h-3 inline mr-1" />
                {session.player_name}
              </span>
            ) : (
              <span className="text-sm text-gray-500">
                <User className="w-3 h-3 inline mr-1" />
                Unassigned
              </span>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2">
          {isCompleted && (
            <button
              onClick={handleReanalyze}
              className="flex items-center gap-2 px-3 py-2 text-sm bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
              Reanalyze
            </button>
          )}
          <button
            onClick={handleDelete}
            className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
            title="Delete session"
          >
            <AlertCircle className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-black rounded-xl overflow-hidden">
            <video
              ref={videoRef}
              src={videoUrl}
              poster={thumbnailUrl || undefined}
              className="w-full aspect-video"
              onTimeUpdate={handleTimeUpdate}
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
              controls={false}
            />
            <div className="bg-gray-900 p-3 flex items-center gap-3">
              <button
                onClick={togglePlay}
                className="p-2 bg-white rounded-full hover:bg-gray-100 transition-colors"
              >
                {isPlaying ? <Pause className="w-4 h-4 text-gray-900" /> : <Play className="w-4 h-4 text-gray-900" />}
              </button>
              <div
                ref={progressRef}
                onClick={handleProgressClick}
                className="flex-1 h-1 bg-gray-700 rounded-full cursor-pointer"
              >
                <div
                  className="h-full bg-brand-500 rounded-full"
                  style={{ width: `${videoRef.current ? (currentTime / videoRef.current.duration) * 100 : 0}%` }}
                />
              </div>
              <span className="text-xs text-white font-mono">
                {formatTime(currentTime)} / {formatTime(session.duration_seconds)}
              </span>
            </div>
          </div>

          {isProcessing && (
            <div className="bg-blue-50 rounded-xl p-6 border border-blue-100">
              <div className="flex items-center gap-3">
                <Loader className="w-6 h-6 text-blue-600 animate-spin" />
                <div>
                  <h3 className="font-medium text-blue-900">Analysis in Progress</h3>
                  <p className="text-sm text-blue-700 mt-1">
                    Our AI is analyzing the video. This may take a few minutes depending on the video length.
                  </p>
                </div>
              </div>
            </div>
          )}

          {!session.player_name && isCompleted && (
            <div className="bg-yellow-50 rounded-xl p-6 border border-yellow-100">
              <div className="flex items-start gap-3">
                <Users className="w-6 h-6 text-yellow-600 mt-0.5" />
                <div className="flex-1">
                  <h3 className="font-medium text-yellow-900">Assign Player</h3>
                  <p className="text-sm text-yellow-700 mt-1 mb-3">
                    This session has no player assigned. Select a player to link this analysis to their profile.
                  </p>
                  <div className="flex items-center gap-2">
                    <select
                      value={selectedPlayer}
                      onChange={(e) => setSelectedPlayer(e.target.value ? Number(e.target.value) : '')}
                      disabled={loadingPlayers || players.length === 0}
                      className="flex-1 px-3 py-2 border border-yellow-200 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent appearance-none bg-white text-sm disabled:opacity-50"
                    >
                      <option value="">
                        {loadingPlayers ? 'Loading players...' : players.length === 0 ? 'No players found' : 'Select a player...'}
                      </option>
                      {players.map((player) => (
                        <option key={player.id} value={player.id}>
                          {player.name} {player.position ? `(${player.position})` : ''}
                        </option>
                      ))}
                    </select>
                    <button
                      onClick={handleAssignPlayer}
                      disabled={!selectedPlayer || assigningPlayer || loadingPlayers}
                      className="px-4 py-2 bg-yellow-600 text-white rounded-lg text-sm font-medium hover:bg-yellow-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
                    >
                      {assigningPlayer ? (
                        <Loader className="w-4 h-4 animate-spin" />
                      ) : (
                        <Save className="w-4 h-4" />
                      )}
                      Assign
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {isCompleted && analysis && (
            <>
              <div className="bg-white rounded-xl p-6 border border-gray-100 shadow-sm">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">AI Summary</h3>
                <div className="prose prose-sm max-w-none">
                  <p className="text-gray-600 leading-relaxed whitespace-pre-wrap">{analysis.coaching_notes || 'No coaching notes available.'}</p>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6 border border-gray-100 shadow-sm">
                <div className="flex items-center gap-2 mb-4">
                  <Zap className="w-5 h-5 text-brand-600" />
                  <h3 className="text-lg font-semibold text-gray-900">Strengths</h3>
                </div>
                <ul className="space-y-2">
                  {analysis.strengths.map((strength, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-gray-600">
                      <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 shrink-0" />
                      {strength}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-white rounded-xl p-6 border border-gray-100 shadow-sm">
                <div className="flex items-center gap-2 mb-4">
                  <Target className="w-5 h-5 text-brand-600" />
                  <h3 className="text-lg font-semibold text-gray-900">Areas for Improvement</h3>
                </div>
                <ul className="space-y-2">
                  {analysis.weaknesses.map((weakness, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-gray-600">
                      <AlertCircle className="w-4 h-4 text-yellow-500 mt-0.5 shrink-0" />
                      {weakness}
                    </li>
                  ))}
                </ul>
              </div>
            </>
          )}
        </div>

        <div className="space-y-6">
          {isCompleted && analysis && (
            <>
              <div className="bg-white rounded-xl p-5 border border-gray-100 shadow-sm">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Performance Scores</h3>
                <div className="h-64">
                  <RadarChart scores={radarScores!} />
                </div>
              </div>

              <KeyMoments moments={analysis.key_moments} />

              <div className="bg-white rounded-xl p-5 border border-gray-100 shadow-sm">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Physical Metrics</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">Total Distance</span>
                    <span className="text-sm font-medium text-gray-900">
                      {analysis.total_distance > 0 ? `${analysis.total_distance.toFixed(1)} m` : 'N/A'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">Max Speed</span>
                    <span className="text-sm font-medium text-gray-900">
                      {analysis.max_speed > 0 ? `${analysis.max_speed.toFixed(1)} km/h` : 'N/A'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">Avg Speed</span>
                    <span className="text-sm font-medium text-gray-900">
                      {analysis.avg_speed > 0 ? `${analysis.avg_speed.toFixed(1)} km/h` : 'N/A'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">Sprint Count</span>
                    <span className="text-sm font-medium text-gray-900">
                      {analysis.sprint_count > 0 ? analysis.sprint_count : 'N/A'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl p-5 border border-gray-100 shadow-sm">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Tactical Metrics</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">Total Passes</span>
                    <span className="text-sm font-medium text-gray-900">
                      {analysis.pass_count > 0 ? analysis.pass_count : 'N/A'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">Shots</span>
                    <span className="text-sm font-medium text-gray-900">
                      {analysis.shot_count > 0 ? analysis.shot_count : 'N/A'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">Tackles</span>
                    <span className="text-sm font-medium text-gray-900">
                      {analysis.tackle_count > 0 ? analysis.tackle_count : 'N/A'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">Ball Touches</span>
                    <span className="text-sm font-medium text-gray-900">
                      {analysis.ball_touches > 0 ? analysis.ball_touches : 'N/A'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl p-5 border border-gray-100 shadow-sm">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Field Visualization</h3>
                <div className="space-y-2">
                  <div className="flex gap-2">
                    {(['heatmap', 'speed', 'passes', 'pressure'] as const).map((metric) => (
                      <button
                        key={metric}
                        onClick={() => setActiveMetric(metric)}
                        className={`px-2 py-1 text-xs rounded-lg font-medium capitalize ${
                          activeMetric === metric
                            ? 'bg-brand-50 text-brand-700'
                            : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
                        }`}
                      >
                        {metric}
                      </button>
                    ))}
                  </div>
                  <div className="h-48">
                    <FieldVisualization type={activeMetric} sessionId={session.id} />
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
