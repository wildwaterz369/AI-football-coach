import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Camera, Users, BarChart3, Play, TrendingUp, Clock, Calendar } from 'lucide-react';
import { sessionAPI, playerAPI } from '../services/api';
import { SessionWithAnalysis, PlayerWithStats } from '../types';
import SessionCard from '../components/SessionCard';
import PlayerCard from '../components/PlayerCard';

export default function Dashboard() {
  const [sessions, setSessions] = useState<SessionWithAnalysis[]>([]);
  const [players, setPlayers] = useState<PlayerWithStats[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [sessionsRes, playersRes] = await Promise.all([
        sessionAPI.list(),
        playerAPI.list(),
      ]);
      setSessions(sessionsRes.data);
      setPlayers(playersRes.data);
    } catch (err) {
      console.error('Failed to load dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  const recentSessions = sessions.slice(0, 3);
  const topPlayers = players.slice(0, 3);
  const totalSessions = sessions.length;
  const totalPlayers = players.length;
  const analyzedSessions = sessions.filter(s => s.status === 'completed').length;
  const avgRating = players.length > 0
    ? players.reduce((sum, p) => sum + p.overall_rating, 0) / players.length
    : 0;

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-1">Overview of your team and training sessions</p>
        </div>
        <Link
          to="/upload"
          className="flex items-center gap-2 px-4 py-2 bg-brand-600 text-white rounded-lg hover:bg-brand-700 transition-colors"
        >
          <Camera className="w-4 h-4" />
          Upload Video
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-gray-100 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Total Sessions</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">{totalSessions}</p>
            </div>
            <div className="w-10 h-10 bg-brand-50 rounded-lg flex items-center justify-center">
              <Play className="w-5 h-5 text-brand-600" />
            </div>
          </div>
          <div className="mt-2 text-xs text-gray-500">
            {analyzedSessions} analyzed
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-gray-100 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Players</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">{totalPlayers}</p>
            </div>
            <div className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-blue-600" />
            </div>
          </div>
          <div className="mt-2 text-xs text-gray-500">
            <Link to="/players" className="text-brand-600 hover:underline">View all</Link>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-gray-100 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Avg Rating</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">{avgRating.toFixed(1)}</p>
            </div>
            <div className="w-10 h-10 bg-yellow-50 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-yellow-600" />
            </div>
          </div>
          <div className="mt-2 text-xs text-gray-500">
            Out of 100
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-gray-100 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Analyzed</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">{analyzedSessions}</p>
            </div>
            <div className="w-10 h-10 bg-green-50 rounded-lg flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-green-600" />
            </div>
          </div>
          <div className="mt-2 text-xs text-gray-500">
            {totalSessions > 0 ? Math.round((analyzedSessions / totalSessions) * 100) : 0}% completion
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Recent Sessions</h2>
            <Link to="/analysis" className="text-sm text-brand-600 hover:text-brand-700">
              View all
            </Link>
          </div>
          <div className="space-y-3">
            {recentSessions.length > 0 ? (
              recentSessions.map(session => (
                <SessionCard key={session.id} session={session} />
              ))
            ) : (
              <div className="bg-white rounded-xl p-8 border border-gray-100 text-center">
                <Camera className="w-8 h-8 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500 mb-3">No sessions yet</p>
                <Link
                  to="/upload"
                  className="text-sm text-brand-600 hover:text-brand-700"
                >
                  Upload your first video
                </Link>
              </div>
            )}
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Top Players</h2>
            <Link to="/players" className="text-sm text-brand-600 hover:text-brand-700">
              View all
            </Link>
          </div>
          <div className="space-y-3">
            {topPlayers.length > 0 ? (
              topPlayers.map((player, index) => (
                <PlayerCard key={player.id} player={player} rank={index + 1} />
              ))
            ) : (
              <div className="bg-white rounded-xl p-8 border border-gray-100 text-center">
                <Users className="w-8 h-8 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500">No player data yet</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
