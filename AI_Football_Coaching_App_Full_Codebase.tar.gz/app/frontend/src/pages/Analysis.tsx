import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Camera, BarChart3, Play, Clock, CheckCircle, Loader, AlertCircle, Filter } from 'lucide-react';
import { sessionAPI } from '../services/api';
import { SessionWithAnalysis } from '../types';
import SessionCard from '../components/SessionCard';

export default function Analysis() {
  const [sessions, setSessions] = useState<SessionWithAnalysis[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'pending' | 'processing' | 'completed' | 'failed'>('all');

  useEffect(() => {
    loadSessions();
  }, []);

  const loadSessions = async () => {
    try {
      const res = await sessionAPI.list();
      setSessions(res.data);
    } catch (err) {
      console.error('Failed to load sessions:', err);
    } finally {
      setLoading(false);
    }
  };

  const filteredSessions = filter === 'all' 
    ? sessions 
    : sessions.filter(s => s.status === filter);

  const statusCounts = {
    all: sessions.length,
    pending: sessions.filter(s => s.status === 'pending').length,
    processing: sessions.filter(s => s.status === 'processing').length,
    completed: sessions.filter(s => s.status === 'completed').length,
    failed: sessions.filter(s => s.status === 'failed').length,
  };

  const statusConfig = {
    all: { label: 'All', icon: BarChart3, color: 'text-gray-600' },
    pending: { label: 'Pending', icon: Clock, color: 'text-yellow-600' },
    processing: { label: 'Processing', icon: Loader, color: 'text-blue-600' },
    completed: { label: 'Completed', icon: CheckCircle, color: 'text-green-600' },
    failed: { label: 'Failed', icon: AlertCircle, color: 'text-red-600' },
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Analysis</h1>
          <p className="text-gray-600 mt-1">View and manage all your video analysis sessions</p>
        </div>
        <Link
          to="/upload"
          className="flex items-center gap-2 px-4 py-2 bg-brand-600 text-white rounded-lg hover:bg-brand-700 transition-colors"
        >
          <Camera className="w-4 h-4" />
          Upload Video
        </Link>
      </div>

      <div className="flex flex-wrap gap-2">
        {(Object.keys(statusConfig) as Array<keyof typeof statusConfig>).map((status) => {
          const config = statusConfig[status];
          const Icon = config.icon;
          return (
            <button
              key={status}
              onClick={() => setFilter(status)}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                filter === status
                  ? 'bg-brand-50 text-brand-700 border border-brand-200'
                  : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
              }`}
            >
              <Icon className={`w-4 h-4 ${config.color}`} />
              {config.label}
              <span className={`px-1.5 py-0.5 rounded text-xs ${
                filter === status ? 'bg-brand-100 text-brand-700' : 'bg-gray-100 text-gray-500'
              }`}>
                {statusCounts[status]}
              </span>
            </button>
          );
        })}
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : (
        <div>
          {filteredSessions.length > 0 ? (
            <div className="space-y-3">
              {filteredSessions.map(session => (
                <SessionCard key={session.id} session={session} />
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-xl p-12 border border-gray-100 text-center">
              <BarChart3 className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 mb-2">
                {filter === 'all' ? 'No sessions yet' : `No ${filter} sessions`}
              </p>
              {filter === 'all' && (
                <Link to="/upload" className="text-brand-600 hover:text-brand-700 text-sm">
                  Upload your first video
                </Link>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
