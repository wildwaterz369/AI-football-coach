import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, User, Star, TrendingUp, Activity, Zap, Target, BarChart3, Calendar } from 'lucide-react';
import { playerAPI, sessionAPI } from '../services/api';
import { PlayerWithStats, SessionWithAnalysis } from '../types';
import RadarChart from '../components/RadarChart';
import KeyMoments from '../components/KeyMoments';
import SessionCard from '../components/SessionCard';

export default function PlayerDetail() {
  const { id } = useParams<{ id: string }>();
  const [player, setPlayer] = useState<PlayerWithStats | null>(null);
  const [sessions, setSessions] = useState<SessionWithAnalysis[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) loadData();
  }, [id]);

  const loadData = async () => {
    try {
      const [playerRes, sessionsRes] = await Promise.all([
        playerAPI.get(Number(id)),
        sessionAPI.list(),
      ]);
      setPlayer(playerRes.data);
      
      // Filter sessions that mention this player in their analysis
      const playerSessions = sessionsRes.data.filter(s => 
        s.analysis && s.player_name === playerRes.data.name
      );
      setSessions(playerSessions);
    } catch (err) {
      console.error('Failed to load player:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!player) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Player not found</p>
        <Link to="/players" className="text-brand-600 hover:text-brand-700 mt-2 inline-block">
          Back to players
        </Link>
      </div>
    );
  }

  const radarScores = {
    dribbling: player.technique_score,
    passing: player.decision_score,
    shooting: player.technique_score * 0.8,
    positioning: player.decision_score,
    physical: player.speed_score,
    overall: player.overall_rating,
  };

  const getRatingColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-blue-600';
    if (score >= 40) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Link to="/players" className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
          <ArrowLeft className="w-5 h-5 text-gray-600" />
        </Link>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">{player.name}</h1>
          <p className="text-gray-600">
            {player.position || 'Unknown position'} {player.jersey_number && `#${player.jersey_number}`}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-xl p-6 border border-gray-100 shadow-sm">
            <div className="flex items-center gap-6 mb-6">
              <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center">
                <User className="w-10 h-10 text-gray-400" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h2 className="text-xl font-bold text-gray-900">{player.name}</h2>
                  <span className={`px-2 py-1 rounded-lg text-xs font-medium ${getRatingColor(player.overall_rating)} bg-gray-50`}>
                    {player.overall_rating.toFixed(1)} Overall
                  </span>
                </div>
                <div className="flex items-center gap-4 text-sm text-gray-500">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    {player.session_count} sessions
                  </span>
                  <span className="flex items-center gap-1">
                    <Zap className="w-4 h-4" />
                    {player.avg_max_speed.toFixed(1)} km/h max
                  </span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              {[
                { label: 'Speed', score: player.speed_score, icon: Zap },
                { label: 'Technique', score: player.technique_score, icon: Target },
                { label: 'Stamina', score: player.stamina_score, icon: Activity },
                { label: 'Decision', score: player.decision_score, icon: BarChart3 },
                { label: 'Overall', score: player.overall_rating, icon: Star },
              ].map(({ label, score, icon: Icon }) => (
                <div key={label} className="text-center p-3 bg-gray-50 rounded-lg">
                  <Icon className="w-5 h-5 text-gray-400 mx-auto mb-2" />
                  <div className={`text-xl font-bold ${getRatingColor(score)}`}>
                    {score.toFixed(0)}
                  </div>
                  <div className="text-xs text-gray-500 mt-1">{label}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 border border-gray-100 shadow-sm">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Performance Radar</h3>
            <div className="h-80">
              <RadarChart scores={radarScores} />
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white rounded-xl p-5 border border-gray-100 shadow-sm">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Stats</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">Total Distance</span>
                <span className="text-sm font-medium text-gray-900">
                  {player.total_distance > 0 ? `${player.total_distance.toFixed(1)} km` : 'N/A'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">Top Speed</span>
                <span className="text-sm font-medium text-gray-900">
                  {player.avg_max_speed > 0 ? `${player.avg_max_speed.toFixed(1)} km/h` : 'N/A'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">Sessions</span>
                <span className="text-sm font-medium text-gray-900">
                  {player.session_count}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">Overall Rating</span>
                <span className="text-sm font-medium text-gray-900">
                  {player.overall_rating.toFixed(1)}
                </span>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl p-5 border border-gray-100 shadow-sm">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Sessions</h3>
            <div className="space-y-3">
              {sessions.length > 0 ? (
                sessions.slice(0, 5).map(session => (
                  <SessionCard key={session.id} session={session} compact />
                ))
              ) : (
                <p className="text-sm text-gray-500">No sessions with this player yet</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
