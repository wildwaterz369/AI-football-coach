import { useAuth } from '../hooks/useAuth';
import { Link, Outlet, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  Upload,
  Dumbbell,
  BarChart3,
  LogOut,
  Menu,
  X,
  Settings,
  CreditCard,
  AlertCircle,
  Crown,
  Zap,
  Shield,
} from 'lucide-react';
import { useState } from 'react';

const planIconMap: Record<string, typeof Crown> = {
  free: Zap,
  pro: Crown,
  elite: Shield,
};

const planColorMap: Record<string, string> = {
  free: 'bg-gray-100 text-gray-600',
  pro: 'bg-brand-100 text-brand-700',
  elite: 'bg-amber-100 text-amber-700',
};

export default function Layout() {
  const { user, subscription, logout } = useAuth();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  const navItems = [
    { path: '/', icon: LayoutDashboard, label: 'Dashboard' },
    { path: '/players', icon: Users, label: 'Players' },
    { path: '/upload', icon: Upload, label: 'Upload Video' },
    { path: '/drills', icon: Dumbbell, label: 'Drills' },
    { path: '/analysis', icon: BarChart3, label: 'Analysis' },
  ];

  const isActive = (path: string) => location.pathname === path;
  const currentPlanId = subscription?.current_plan?.id || 'free';
  const PlanIcon = planIconMap[currentPlanId] || Zap;
  const planColor = planColorMap[currentPlanId] || planColorMap.free;

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className={`${mobileOpen ? 'block' : 'hidden'} md:flex w-64 flex-col bg-white border-r border-gray-200 fixed md:relative h-full z-50`}>
        <div className="p-6">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-brand-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">AI</span>
            </div>
            <h1 className="text-xl font-bold text-gray-900">Football Coach</h1>
          </div>
        </div>

        <nav className="flex-1 px-4 space-y-1">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              onClick={() => setMobileOpen(false)}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                isActive(item.path)
                  ? 'bg-brand-50 text-brand-700'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              }`}
            >
              <item.icon className="w-5 h-5" />
              {item.label}
            </Link>
          ))}
        </nav>

        {/* Quota & Plan Info */}
        <div className="px-4 mb-4">
          <div className="bg-gray-50 rounded-lg p-3 border border-gray-100">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-gray-500">Plan</span>
              <Link
                to="/subscription"
                className={`flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold ${planColor} hover:opacity-80 transition-opacity`}
              >
                <PlanIcon className="w-3 h-3" />
                {subscription?.current_plan?.name || 'Free'}
              </Link>
            </div>
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-gray-500">Quota used</span>
              <span className={`font-medium ${
                subscription?.has_quota ? 'text-gray-700' : 'text-red-600'
              }`}>
                {subscription?.analysis_used || 0} / {subscription?.analysis_quota || 0}
              </span>
            </div>
            <div className="w-full h-1.5 bg-gray-200 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all ${
                  (subscription?.percent_used || 0) > 90
                    ? 'bg-red-500'
                    : (subscription?.percent_used || 0) > 70
                    ? 'bg-amber-500'
                    : 'bg-brand-500'
                }`}
                style={{ width: `${Math.min(subscription?.percent_used || 0, 100)}%` }}
              />
            </div>
            {!subscription?.has_quota && (
              <div className="mt-2 flex items-center gap-1 text-xs text-red-600">
                <AlertCircle className="w-3 h-3" />
                <Link to="/subscription" className="underline hover:text-red-700">
                  Upgrade to continue
                </Link>
              </div>
            )}
          </div>
        </div>

        <div className="p-4 border-t border-gray-200 space-y-1">
          <Link
            to="/subscription"
            onClick={() => setMobileOpen(false)}
            className={`flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors ${
              isActive('/subscription')
                ? 'bg-brand-50 text-brand-700'
                : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
            }`}
          >
            <CreditCard className="w-4 h-4" />
            Subscription
          </Link>
          <Link
            to="/settings"
            onClick={() => setMobileOpen(false)}
            className={`flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors ${
              isActive('/settings')
                ? 'bg-brand-50 text-brand-700'
                : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
            }`}
          >
            <Settings className="w-4 h-4" />
            Settings
          </Link>
          <div className="px-4 py-2">
            <p className="text-sm font-medium text-gray-900">{user?.full_name}</p>
            <p className="text-xs text-gray-500">{user?.team_name || 'Coach'}</p>
          </div>
          <button
            onClick={logout}
            className="flex items-center gap-3 w-full px-4 py-2 text-sm text-red-600 hover:bg-red-50 rounded-lg"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Mobile header */}
      <div className="md:hidden fixed top-0 left-0 right-0 h-16 bg-white border-b border-gray-200 flex items-center justify-between px-4 z-40">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-brand-600 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-sm">AI</span>
          </div>
          <h1 className="text-lg font-bold text-gray-900">Football Coach</h1>
        </div>
        <div className="flex items-center gap-2">
          <Link to="/subscription" className="flex items-center gap-1 px-2 py-1 bg-gray-100 rounded-lg text-xs font-medium text-gray-600">
            <PlanIcon className="w-3 h-3" />
            {subscription?.current_plan?.name || 'Free'}
          </Link>
          <button onClick={() => setMobileOpen(!mobileOpen)}>
            {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Main content */}
      <main className="flex-1 overflow-y-auto md:pt-0 pt-16">
        <Outlet />
      </main>
    </div>
  );
}
