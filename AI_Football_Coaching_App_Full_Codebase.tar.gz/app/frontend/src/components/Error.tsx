import { AlertTriangle, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

interface ErrorProps {
  title?: string;
  message?: string;
  retry?: () => void;
  backTo?: string;
  backLabel?: string;
  className?: string;
}

export default function Error({
  title = 'Something went wrong',
  message = 'An error occurred while loading this page. Please try again.',
  retry,
  backTo,
  backLabel = 'Go Back',
  className = ''
}: ErrorProps) {
  return (
    <div className={`flex items-center justify-center min-h-[60vh] ${className}`}>
      <div className="text-center max-w-md px-6">
        <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <AlertTriangle className="w-8 h-8 text-red-600" />
        </div>
        <h2 className="text-lg font-semibold text-gray-900 mb-2">{title}</h2>
        <p className="text-sm text-gray-500 mb-6">{message}</p>
        <div className="flex items-center justify-center gap-3">
          {retry && (
            <button
              onClick={retry}
              className="px-4 py-2 bg-brand-600 text-white rounded-lg text-sm font-medium hover:bg-brand-700 transition-colors"
            >
              Try Again
            </button>
          )}
          {backTo && (
            <Link
              to={backTo}
              className="inline-flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-200 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              {backLabel}
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}
