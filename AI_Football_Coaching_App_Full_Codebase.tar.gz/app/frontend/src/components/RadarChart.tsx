interface RadarChartProps {
  scores: {
    dribbling: number;
    passing: number;
    shooting: number;
    positioning: number;
    physical: number;
    overall: number;
  };
  size?: number;
}

export default function RadarChart({ scores, size = 200 }: RadarChartProps) {
  const categories = [
    { key: 'dribbling', label: 'Dribbling', value: scores.dribbling },
    { key: 'passing', label: 'Passing', value: scores.passing },
    { key: 'shooting', label: 'Shooting', value: scores.shooting },
    { key: 'positioning', label: 'Position', value: scores.positioning },
    { key: 'physical', label: 'Physical', value: scores.physical },
    { key: 'overall', label: 'Overall', value: scores.overall },
  ];

  const center = size / 2;
  const radius = size / 2 - 40;
  const angleStep = (2 * Math.PI) / categories.length;

  const getPoint = (index: number, value: number) => {
    const angle = index * angleStep - Math.PI / 2;
    const r = (value / 100) * radius;
    return {
      x: center + r * Math.cos(angle),
      y: center + r * Math.sin(angle),
    };
  };

  const points = categories.map((cat, i) => getPoint(i, cat.value));
  const pointsStr = points.map(p => `${p.x},${p.y}`).join(' ');

  return (
    <div className="flex flex-col items-center">
      <svg width={size} height={size} className="transform">
        {/* Background grid */}
        {[20, 40, 60, 80, 100].map((level) => (
          <polygon
            key={level}
            points={categories.map((_, i) => {
              const p = getPoint(i, level);
              return `${p.x},${p.y}`;
            }).join(' ')}
            fill="none"
            stroke="#e5e7eb"
            strokeWidth="1"
          />
        ))}

        {/* Axis lines */}
        {categories.map((_, i) => {
          const p = getPoint(i, 100);
          return (
            <line
              key={i}
              x1={center}
              y1={center}
              x2={p.x}
              y2={p.y}
              stroke="#e5e7eb"
              strokeWidth="1"
            />
          );
        })}

        {/* Data polygon */}
        <polygon
          points={pointsStr}
          fill="rgba(16, 185, 129, 0.2)"
          stroke="#10b981"
          strokeWidth="2"
        />

        {/* Data points */}
        {points.map((p, i) => (
          <circle
            key={i}
            cx={p.x}
            cy={p.y}
            r="4"
            fill="#10b981"
            stroke="white"
            strokeWidth="2"
          />
        ))}

        {/* Labels */}
        {categories.map((cat, i) => {
          const angle = i * angleStep - Math.PI / 2;
          const labelR = radius + 25;
          const x = center + labelR * Math.cos(angle);
          const y = center + labelR * Math.sin(angle);
          return (
            <text
              key={i}
              x={x}
              y={y}
              textAnchor="middle"
              dominantBaseline="middle"
              className="text-xs fill-gray-600 font-medium"
              style={{ fontSize: '10px' }}
            >
              {cat.label}
            </text>
          );
        })}
      </svg>
    </div>
  );
}
