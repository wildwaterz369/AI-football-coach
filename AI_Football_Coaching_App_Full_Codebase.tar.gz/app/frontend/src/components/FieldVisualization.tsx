import React from 'react';

interface FieldVisualizationProps {
  type: 'heatmap' | 'speed' | 'passes' | 'pressure';
  sessionId: number;
}

export default function FieldVisualization({ type }: FieldVisualizationProps) {
  // This is a placeholder visualization component
  // In a real implementation, this would render actual heatmap/pass data
  
  const renderContent = () => {
    switch (type) {
      case 'heatmap':
        return (
          <div className="relative w-full h-full bg-green-50 rounded-lg overflow-hidden">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-full h-full relative">
                {/* Field outline */}
                <div className="absolute inset-4 border-2 border-green-200 rounded-lg">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-1/2 h-full border-x-2 border-green-200" />
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-16 h-16 border-2 border-green-200 rounded-full" />
                  </div>
                </div>
                {/* Heatmap zones */}
                <div className="absolute top-1/4 left-1/4 w-1/4 h-1/4 bg-red-400/40 rounded-full blur-xl" />
                <div className="absolute top-1/3 left-1/2 w-1/5 h-1/5 bg-orange-400/40 rounded-full blur-xl" />
                <div className="absolute bottom-1/4 right-1/4 w-1/4 h-1/4 bg-yellow-400/40 rounded-full blur-xl" />
                <div className="absolute top-1/2 left-1/3 w-1/6 h-1/6 bg-red-500/50 rounded-full blur-xl" />
              </div>
            </div>
            <div className="absolute bottom-2 left-2 text-xs text-gray-500 bg-white/80 px-2 py-1 rounded">
              Activity Heatmap
            </div>
          </div>
        );
      
      case 'speed':
        return (
          <div className="relative w-full h-full bg-blue-50 rounded-lg overflow-hidden">
            <div className="absolute inset-4 border-2 border-blue-200 rounded-lg">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-1/2 h-full border-x-2 border-blue-200" />
              </div>
              {/* Speed zones */}
              <div className="absolute top-1/4 left-1/4 w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-xs font-bold">
                28
              </div>
              <div className="absolute top-1/2 left-1/2 w-8 h-8 bg-blue-400 rounded-full flex items-center justify-center text-white text-xs font-bold">
                25
              </div>
              <div className="absolute bottom-1/3 right-1/3 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white text-xs font-bold">
                32
              </div>
              <div className="absolute top-1/3 right-1/4 w-8 h-8 bg-blue-300 rounded-full flex items-center justify-center text-white text-xs font-bold">
                22
              </div>
            </div>
            <div className="absolute bottom-2 left-2 text-xs text-gray-500 bg-white/80 px-2 py-1 rounded">
              Speed Zones (km/h)
            </div>
          </div>
        );
      
      case 'passes':
        return (
          <div className="relative w-full h-full bg-purple-50 rounded-lg overflow-hidden">
            <div className="absolute inset-4 border-2 border-purple-200 rounded-lg">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-1/2 h-full border-x-2 border-purple-200" />
              </div>
              {/* Pass arrows */}
              <svg className="absolute inset-0 w-full h-full">
                <defs>
                  <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                    <polygon points="0 0, 10 3.5, 0 7" fill="#a855f7" />
                  </marker>
                </defs>
                <line x1="20%" y1="30%" x2="50%" y2="40%" stroke="#a855f7" strokeWidth="2" markerEnd="url(#arrowhead)" />
                <line x1="50%" y1="40%" x2="80%" y2="35%" stroke="#a855f7" strokeWidth="2" markerEnd="url(#arrowhead)" />
                <line x1="30%" y1="60%" x2="60%" y2="50%" stroke="#a855f7" strokeWidth="2" markerEnd="url(#arrowhead)" />
                <line x1="70%" y1="70%" x2="40%" y2="60%" stroke="#a855f7" strokeWidth="2" markerEnd="url(#arrowhead)" />
                <line x1="50%" y1="50%" x2="30%" y2="30%" stroke="#a855f7" strokeWidth="2" markerEnd="url(#arrowhead)" />
              </svg>
              {/* Pass origin points */}
              <div className="absolute top-[30%] left-[20%] w-4 h-4 bg-purple-500 rounded-full" />
              <div className="absolute top-[40%] left-[50%] w-4 h-4 bg-purple-500 rounded-full" />
              <div className="absolute top-[60%] left-[30%] w-4 h-4 bg-purple-500 rounded-full" />
              <div className="absolute top-[70%] left-[70%] w-4 h-4 bg-purple-500 rounded-full" />
            </div>
            <div className="absolute bottom-2 left-2 text-xs text-gray-500 bg-white/80 px-2 py-1 rounded">
              Pass Network
            </div>
          </div>
        );
      
      case 'pressure':
        return (
          <div className="relative w-full h-full bg-red-50 rounded-lg overflow-hidden">
            <div className="absolute inset-4 border-2 border-red-200 rounded-lg">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-1/2 h-full border-x-2 border-red-200" />
              </div>
              {/* Pressure zones */}
              <div className="absolute top-[20%] left-[15%] w-1/4 h-1/5 bg-red-500/30 rounded-lg" />
              <div className="absolute top-[30%] right-[20%] w-1/5 h-1/4 bg-red-400/30 rounded-lg" />
              <div className="absolute bottom-[25%] left-[40%] w-1/4 h-1/5 bg-red-600/30 rounded-lg" />
              <div className="absolute top-[50%] left-[25%] w-6 h-6 bg-red-700 rounded-full flex items-center justify-center text-white text-xs font-bold">
                H
              </div>
              <div className="absolute top-[35%] right-[30%] w-6 h-6 bg-red-500 rounded-full flex items-center justify-center text-white text-xs font-bold">
                M
              </div>
            </div>
            <div className="absolute bottom-2 left-2 text-xs text-gray-500 bg-white/80 px-2 py-1 rounded">
              Pressure Zones (H=High, M=Medium)
            </div>
          </div>
        );
    }
  };

  return (
    <div className="w-full h-full">
      {renderContent()}
    </div>
  );
}
