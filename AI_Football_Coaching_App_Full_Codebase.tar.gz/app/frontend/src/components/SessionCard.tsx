import { Link } from 'react-router-dom';
import { Clock, CheckCircle, Loader, AlertCircle, User } from 'lucide-react';
import { SessionWithAnalysis } from '../types';

interface SessionCardProps {
  session: SessionWithAnalysis;
  compact?: boolean;
}

export default function SessionCard({ session, compact }: SessionCardProps) {
  const statusConfig = {
    completed: { icon: CheckCircle, color: 'text-green-500', bg: 'bg-green-50' },
    processing: { icon: Loader, color: 'text-blue-500', bg: 'bg-blue-50' },
    pending: { icon: Clock, color: 'text-yellow-500', bg: 'bg-yellow-50' },
    failed: { icon: AlertCircle, color: 'text-red-500', bg: 'bg-red-50' },
  };

  const config = statusConfig[session.status as keyof typeof statusConfig] || statusConfig.pending;
  const StatusIcon = config.icon;

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${String(secs).padStart(2, '0')}`;
  };

  if (compact) {
    return (
      <Link
        to={`/analysis/${session.id}`}
        className="block bg-gray-50 rounded-lg p-3 border border-gray-100 hover:border-brand-200 hover:bg-gray-100 transition-all"
      >
        <div className="flex items-center gap-3">
          <StatusIcon className={`w-4 h-4 ${config.color} ${session.status === 'processing' ? 'animate-spin' : ''}`} />
          <div className="flex-1 min-w-0">
            <h4 className="text-sm font-medium text-gray-900 truncate">{session.title}</h4>
            <p className="text-xs text-gray-500 mt-0.5">{formatDate(session.date)}</p>
          </div>
          <span className={`text-xs font-medium px-2 py-0.5 rounded-full capitalize ${config.bg} ${config.color}`}>
            {session.status}
          </span>
        </div>
      </Link>
    );
  }

  return (
    <Link
      to={`/analysis/${session.id}`}
      className="block bg-white rounded-xl p-4 border border-gray-100 hover:border-brand-200 hover:shadow-sm transition-all"
    >
      <div className="flex items-center gap-4">
        <div className={`p-3 rounded-lg ${config.bg}`}>
          <StatusIcon className={`w-5 h-5 ${config.color} ${session.status === 'processing' ? 'animate-spin' : ''}`} />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-medium text-gray-900 truncate">{session.title}</h3>
          <div className="flex items-center gap-3 mt-1 text-sm text-gray-500">
            <span>{formatDate(session.date)}</span>
            {session.duration_seconds > 0 && (
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {formatDuration(session.duration_seconds)}
              </span>
            )}
            {session.player_name && (
              <span className="flex items-center gap-1">
                <User className="w-3 h-3" />
                {session.player_name}
              </span>
            )}
          </div>
        </div>
        <div className="text-right">
          <span className={`text-xs font-medium px-2 py-1 rounded-full capitalize ${config.bg} ${config.color}`}>
            {session.status}
          </span>
          {session.analysis && (
            <div className="text-xs text-gray-500 mt-1">
              Overall: {session.analysis.overall_score.toFixed(0)}
            </div>
          )}
        </div>
      </div>
    </Link>
  );
}
