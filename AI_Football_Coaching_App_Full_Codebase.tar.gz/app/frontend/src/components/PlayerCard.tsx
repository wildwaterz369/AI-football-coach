import { User, Star, TrendingUp, Activity } from 'lucide-react';
import { PlayerWithStats } from '../types';
import { Link } from 'react-router-dom';

interface PlayerCardProps {
  player: PlayerWithStats;
  rank?: number;
}

export default function PlayerCard({ player, rank }: PlayerCardProps) {
  const getOverallColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-blue-600';
    if (score >= 40) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="bg-white rounded-xl p-5 border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center">
            <User className="w-6 h-6 text-gray-400" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">{player.name}</h3>
            <p className="text-sm text-gray-500">
              {player.position || 'Unknown position'} {player.jersey_number && `#${player.jersey_number}`}
            </p>
          </div>
        </div>
        {rank && (
          <div className="w-8 h-8 bg-brand-100 rounded-full flex items-center justify-center">
            <span className="text-sm font-bold text-brand-700">{rank}</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="text-center p-2 bg-gray-50 rounded-lg">
          <div className={`text-2xl font-bold ${getOverallColor(player.overall_rating)}`}>
            {player.overall_rating.toFixed(1)}
          </div>
          <div className="text-xs text-gray-500 flex items-center justify-center gap-1 mt-1">
            <Star className="w-3 h-3" />
            Overall
          </div>
        </div>
        <div className="text-center p-2 bg-gray-50 rounded-lg">
          <div className="text-2xl font-bold text-gray-900">
            {player.avg_max_speed.toFixed(1)}
          </div>
          <div className="text-xs text-gray-500 flex items-center justify-center gap-1 mt-1">
            <Activity className="w-3 h-3" />
            Max km/h
          </div>
        </div>
      </div>

      <div className="space-y-2 mb-4">
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-500">Speed</span>
          <div className="flex items-center gap-2">
            <div className="w-24 h-2 bg-gray-100 rounded-full overflow-hidden">
              <div 
                className="h-full bg-brand-500 rounded-full transition-all"
                style={{ width: `${player.speed_score}%` }}
              />
            </div>
            <span className="text-sm font-medium text-gray-700 w-8">{player.speed_score.toFixed(0)}</span>
          </div>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-500">Technique</span>
          <div className="flex items-center gap-2">
            <div className="w-24 h-2 bg-gray-100 rounded-full overflow-hidden">
              <div 
                className="h-full bg-blue-500 rounded-full transition-all"
                style={{ width: `${player.technique_score}%` }}
              />
            </div>
            <span className="text-sm font-medium text-gray-700 w-8">{player.technique_score.toFixed(0)}</span>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between pt-3 border-t border-gray-100">
        <div className="text-xs text-gray-500">
          <TrendingUp className="w-3 h-3 inline mr-1" />
          {player.session_count} sessions
        </div>
        <Link
          to={`/players/${player.id}`}
          className="text-sm font-medium text-brand-600 hover:text-brand-700"
        >
          View details →
        </Link>
      </div>
    </div>
  );
}
