interface HeatmapProps {
  grid: number[][];
  maxIntensity: number;
}

export default function Heatmap({ grid, maxIntensity }: HeatmapProps) {
  if (!grid || grid.length === 0) return null;

  const getColor = (value: number) => {
    const intensity = Math.min(value / (maxIntensity || 1), 1);
    const r = Math.round(255 * (1 - intensity * 0.7));
    const g = Math.round(255 * (1 - intensity * 0.3));
    const b = Math.round(255 * (1 - intensity * 0.9));
    return `rgb(${r}, ${g}, ${b})`;
  };

  return (
    <div className="bg-white rounded-xl p-6 border border-gray-100 shadow-sm">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Position Heatmap</h3>
      <div className="relative">
        {/* Field outline */}
        <div 
          className="border-2 border-gray-300 rounded-sm relative bg-green-50"
          style={{ aspectRatio: '1.5' }}
        >
          {/* Center line */}
          <div className="absolute left-1/2 top-0 bottom-0 w-0.5 bg-gray-300" />
          {/* Center circle */}
          <div className="absolute left-1/2 top-1/2 w-16 h-16 border-2 border-gray-300 rounded-full -translate-x-1/2 -translate-y-1/2" />
          
          {/* Goal areas */}
          <div className="absolute left-0 top-1/4 w-12 h-1/2 border-2 border-gray-300 border-l-0" />
          <div className="absolute right-0 top-1/4 w-12 h-1/2 border-2 border-gray-300 border-r-0" />

          {/* Heatmap grid overlay */}
          <div className="absolute inset-0 grid" style={{ gridTemplateColumns: `repeat(${grid[0].length}, 1fr)`, gridTemplateRows: `repeat(${grid.length}, 1fr)` }}>
            {grid.flat().map((cell, i) => (
              <div
                key={i}
                className="w-full h-full transition-colors"
                style={{ backgroundColor: getColor(cell) }}
              />
            ))}
          </div>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-3 mt-4">
          <span className="text-xs text-gray-500">Low activity</span>
          <div className="flex gap-1">
            {[0, 0.2, 0.4, 0.6, 0.8, 1].map((v) => (
              <div
                key={v}
                className="w-6 h-4 rounded-sm"
                style={{ backgroundColor: getColor(v * maxIntensity) }}
              />
            ))}
          </div>
          <span className="text-xs text-gray-500">High activity</span>
        </div>
      </div>
    </div>
  );
}
