import { Zap, Target, Activity, Shield, Trophy } from 'lucide-react';
import { KeyMoment } from '../types';

interface KeyMomentsProps {
  moments: KeyMoment[];
}

const typeIcons = {
  sprint: Zap,
  shot: Target,
  pass: Activity,
  tackle: Shield,
  dribble: Activity,
  goal: Trophy,
};

const typeColors = {
  sprint: 'bg-yellow-50 text-yellow-700 border-yellow-200',
  shot: 'bg-red-50 text-red-700 border-red-200',
  pass: 'bg-blue-50 text-blue-700 border-blue-200',
  tackle: 'bg-purple-50 text-purple-700 border-purple-200',
  dribble: 'bg-green-50 text-green-700 border-green-200',
  goal: 'bg-brand-50 text-brand-700 border-brand-200',
};

export default function KeyMoments({ moments }: KeyMomentsProps) {
  if (!moments || moments.length === 0) {
    return (
      <div className="bg-white rounded-xl p-6 border border-gray-100 shadow-sm">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Key Moments</h3>
        <p className="text-gray-500 text-sm">No key moments detected in this session.</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl p-6 border border-gray-100 shadow-sm">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Key Moments</h3>
      <div className="space-y-3 max-h-96 overflow-y-auto">
        {moments.map((moment, index) => {
          const Icon = typeIcons[moment.type as keyof typeof typeIcons] || Activity;
          const colorClass = typeColors[moment.type as keyof typeof typeColors] || 'bg-gray-50 text-gray-700 border-gray-200';
          
          return (
            <div
              key={index}
              className={`flex items-center gap-3 p-3 rounded-lg border ${colorClass}`}
            >
              <div className="p-2 rounded-lg bg-white/60">
                <Icon className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-sm capitalize">{moment.type}</span>
                  <span className="text-xs opacity-70">
                    {Math.floor(moment.timestamp / 60)}:{String(Math.floor(moment.timestamp % 60)).padStart(2, '0')}
                  </span>
                </div>
                <p className="text-sm opacity-90 truncate">{moment.description}</p>
              </div>
              <div className="text-xs font-medium opacity-70">
                {Math.round(moment.confidence * 100)}%
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
