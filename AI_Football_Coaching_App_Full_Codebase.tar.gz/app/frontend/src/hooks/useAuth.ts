import { useState, useEffect, createContext, useContext, ReactNode } from 'react';
import api from '../api/client';
import { User, SubscriptionStatus } from '../types';

interface AuthContextType {
  user: User | null;
  setUser: (user: User | null) => void;
  subscription: SubscriptionStatus | null;
  isLoading: boolean;
  isLoadingSubscription: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string, fullName: string, teamName?: string) => Promise<void>;
  logout: () => void;
  refreshSubscription: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [subscription, setSubscription] = useState<SubscriptionStatus | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isLoadingSubscription, setIsLoadingSubscription] = useState(false);

  useEffect(() => {
    checkAuth();
  }, []);

  useEffect(() => {
    if (user) {
      fetchSubscription();
    } else {
      setSubscription(null);
    }
  }, [user]);

  const checkAuth = async () => {
    const token = localStorage.getItem('token');
    if (token) {
      try {
        const { data } = await api.get('/auth/me');
        setUser(data);
      } catch {
        localStorage.removeItem('token');
      }
    }
    setIsLoading(false);
  };

  const fetchSubscription = async () => {
    setIsLoadingSubscription(true);
    try {
      const { data } = await api.get('/subscription');
      setSubscription(data);
    } catch (err) {
      console.error('Failed to fetch subscription:', err);
    } finally {
      setIsLoadingSubscription(false);
    }
  };

  const login = async (email: string, password: string) => {
    const formData = new URLSearchParams();
    formData.append('username', email);
    formData.append('password', password);

    const { data } = await api.post('/auth/login', formData, {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
    });

    localStorage.setItem('token', data.access_token);
    const { data: userData } = await api.get('/auth/me');
    setUser(userData);
  };

  const register = async (email: string, password: string, fullName: string, teamName?: string) => {
    const { data } = await api.post('/auth/register', {
      email,
      password,
      full_name: fullName,
      team_name: teamName,
      role: 'coach'
    });

    await login(email, password);
    return data;
  };

  const logout = () => {
    localStorage.removeItem('token');
    setUser(null);
    setSubscription(null);
    window.location.href = '/login';
  };

  return (
    <AuthContext.Provider value={{
      user,
      setUser,
      subscription,
      isLoading,
      isLoadingSubscription,
      login,
      register,
      logout,
      refreshSubscription: fetchSubscription
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
}
