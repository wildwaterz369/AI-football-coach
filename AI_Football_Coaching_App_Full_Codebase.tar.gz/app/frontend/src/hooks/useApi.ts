import { useState, useEffect, useCallback } from 'react';
import api from '../api/client';

export function useApi<T>(url: string, deps: any[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetch = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const { data: responseData } = await api.get(url);
      setData(responseData);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to load data');
    } finally {
      setLoading(false);
    }
  }, [url]);

  useEffect(() => {
    fetch();
  }, deps);

  return { data, loading, error, refetch: fetch };
}

export function usePost<T>(url: string) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<T | null>(null);

  const post = async (payload: any) => {
    try {
      setLoading(true);
      setError(null);
      const { data: responseData } = await api.post(url, payload);
      setData(responseData);
      return responseData;
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to submit');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return { post, loading, error, data };
}
