export interface User {
  id: number;
  email: string;
  full_name: string;
  role: string;
  team_name: string | null;
}

export interface Player {
  id: number;
  user_id: number;
  name: string;
  jersey_number: number | null;
  position: string | null;
  age: number | null;
  height: number | null;
  weight: number | null;
  dominant_foot: string;
  overall_rating: number;
  speed_score: number;
  technique_score: number;
  stamina_score: number;
  decision_score: number;
  created_at: string;
}

export interface PlayerWithStats extends Player {
  session_count: number;
  total_distance: number;
  avg_max_speed: number;
}

export interface Session {
  id: number;
  player_id: number;
  user_id: number;
  title: string;
  session_type: string;
  date: string;
  duration_seconds: number;
  video_path: string | null;
  thumbnail_path: string | null;
  status: string;
}

export interface SessionWithAnalysis extends Session {
  analysis: Analysis | null;
  player_name: string | null;
}

export interface Analysis {
  id: number;
  session_id: number;
  total_distance: number;
  max_speed: number;
  avg_speed: number;
  sprint_count: number;
  ball_touches: number;
  pass_count: number;
  shot_count: number;
  tackle_count: number;
  dribbling_score: number;
  passing_score: number;
  shooting_score: number;
  positioning_score: number;
  physical_score: number;
  overall_score: number;
  strengths: string[];
  weaknesses: string[];
  recommendations: string[];
  coaching_notes: string | null;
  key_moments: KeyMoment[];
  heatmap_data: HeatmapData;
  created_at: string;
}

export interface KeyMoment {
  timestamp: number;
  type: string;
  description: string;
  confidence: number;
  frame_index: number;
}

export interface HeatmapData {
  grid: number[][];
  max_intensity: number;
}

export interface DashboardStats {
  total_players: number;
  total_sessions: number;
  total_videos_analyzed: number;
  avg_overall_rating: number;
  top_performers: PlayerWithStats[];
  recent_sessions: SessionWithAnalysis[];
  weekly_activity: WeeklyActivity[];
  skill_distribution: SkillDistribution;
}

export interface WeeklyActivity {
  week: string;
  sessions: number;
  videos: number;
}

export interface SkillDistribution {
  elite: number;
  advanced: number;
  intermediate: number;
  beginner: number;
}

export interface PerformanceTrend {
  player_id: number;
  player_name: string;
  dates: string[];
  overall_scores: number[];
  physical_scores: number[];
  technique_scores: number[];
}

export interface DrillTemplate {
  id: number;
  name: string;
  description: string;
  category: string;
  difficulty: string;
  duration_minutes: number;
  target_metrics: string[];
  instructions: string[];
  video_demo_url: string | null;
}

export interface AIFeedbackResponse {
  answer: string;
  related_moments: KeyMoment[];
  suggested_drills: string[];
}

export interface VideoUploadResponse {
  session_id: number;
  status: string;
  message: string;
  analysis_preview: Analysis | null;
}

export interface VideoStatusResponse {
  session_id: number;
  status: string;
  progress: number;
  analysis: Analysis | null;
  error_message: string | null;
}

// Subscription types
export interface Plan {
  id: string;
  name: string;
  price_monthly_cny: number;
  analysis_quota: number;
  features: string[];
}

export interface Subscription {
  id: number;
  user_id: number;
  plan_id: string;
  status: string;
  current_period_start: string | null;
  current_period_end: string | null;
  stripe_subscription_id: string | null;
  stripe_customer_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface SubscriptionWithPlan extends Subscription {
  plan: Plan;
}

export interface SubscriptionStatus {
  current_plan: Plan;
  active_subscription: SubscriptionWithPlan | null;
  analysis_used: number;
  analysis_quota: number;
  has_quota: boolean;
  percent_used: number;
}

export interface PaymentIntent {
  client_secret: string;
  payment_intent_id: string;
  stripe_public_key: string;
  plan_id: string;
  plan_name: string;
  amount_cny: number;
  message: string;
}

export interface AlipayOrder {
  order_string: string;
  order_id: string;
  plan_id: string;
  plan_name: string;
  amount_cny: number;
  message: string;
  alipay_public_key: string;
}

export interface SubscriptionActionResponse {
  message: string;
  subscription: SubscriptionWithPlan;
}

export interface UpdateProfileRequest {
  full_name?: string;
  team_name?: string;
  current_password?: string;
  new_password?: string;
}

export interface UpdateProfileResponse {
  message: string;
  user: User;
}
