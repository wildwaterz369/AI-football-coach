import api from '../api/client';

// Player API
export const playerAPI = {
  list: () => api.get('/players'),
  get: (id: number) => api.get(`/players/${id}`),
  create: (data: { name: string; position?: string; jersey_number?: number; notes?: string }) =>
    api.post('/players', data),
  update: (id: number, data: any) => api.put(`/players/${id}`, data),
  delete: (id: number) => api.delete(`/players/${id}`),
};

// Session / Analysis API
export const sessionAPI = {
  list: () => api.get('/sessions'),
  get: (id: number) => api.get(`/sessions/${id}`),
  create: (data: { title: string; description?: string; player_id?: number }) =>
    api.post('/sessions', data),
  update: (id: number, data: { title?: string; session_type?: string; player_id?: number | null }) =>
    api.put(`/sessions/${id}`, data),
  upload: (formData: FormData, onProgress?: (progress: number) => void) => {
    return api.post('/upload-video', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
      onUploadProgress: (progressEvent) => {
        if (progressEvent.total && onProgress) {
          const progress = Math.round((progressEvent.loaded * 100) / progressEvent.total);
          onProgress(progress);
        }
      },
    });
  },
  delete: (id: number) => api.delete(`/sessions/${id}`),
  reanalyze: (id: number) => api.post(`/sessions/${id}/reanalyze`),
  status: (id: number) => api.get(`/video-status/${id}`),
};

// Dashboard API
export const dashboardAPI = {
  stats: () => api.get('/dashboard'),
};

// AI Feedback API
export const aiAPI = {
  feedback: (data: { session_id: number; question: string }) =>
    api.post('/ai-feedback', data),
};

// Subscription API
export const subscriptionAPI = {
  status: () => api.get('/subscription'),
  plans: () => api.get('/subscription/plans'),
  createStripeCheckout: (planId: string) =>
    api.post('/subscription/checkout', { plan_id: planId, payment_method: 'stripe' }),
  createAlipayOrder: (planId: string) =>
    api.post('/subscription/checkout', { plan_id: planId, payment_method: 'alipay' }),
  cancel: () => api.post('/subscription/cancel'),
  resume: () => api.post('/subscription/resume'),
};

// User Profile API
export const userAPI = {
  me: () => api.get('/auth/me'),
  update: (data: { full_name?: string; team_name?: string; current_password?: string; new_password?: string }) =>
    api.put('/auth/profile', data),
};

export default { playerAPI, sessionAPI, dashboardAPI, aiAPI, subscriptionAPI, userAPI };
