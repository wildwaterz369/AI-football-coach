from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime

# ==================== USER SCHEMAS ====================
class UserBase(BaseModel):
    email: str
    full_name: str
    role: str = "coach"
    team_name: Optional[str] = None

class UserCreate(UserBase):
    password: str

class UserResponse(UserBase):
    id: int
    created_at: datetime
    is_active: bool
    subscription_plan: str = "free"
    subscription_status: str = "inactive"
    analysis_count_monthly: int = 0
    analysis_limit: int = 1
    is_pro: bool = False
    subscription_expires_at: Optional[datetime] = None
    trial_ends_at: Optional[datetime] = None
    next_billing_date: Optional[datetime] = None
    
    class Config:
        from_attributes = True

class UserLogin(BaseModel):
    email: str
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"

# ==================== SUBSCRIPTION SCHEMAS ====================
class SubscriptionPlan(BaseModel):
    id: str
    name: str
    description: str
    price: int  # in kobo (Nigerian naira) or cents
    price_display: str
    analysis_limit: int
    features: List[str]
    popular: bool = False

class SubscriptionResponse(BaseModel):
    plan: str
    status: str
    analysis_count_monthly: int
    analysis_limit: int
    subscription_expires_at: Optional[datetime] = None
    next_billing_date: Optional[datetime] = None
    is_trial: bool = False

class SubscriptionUpgradeRequest(BaseModel):
    plan: str  # pro, team
    payment_method: str = "card"  # card, bank_transfer, etc.

# ==================== PAYMENT SCHEMAS ====================
class PaymentInitiateRequest(BaseModel):
    plan: str
    email: Optional[str] = None  # uses current user email if not provided
    callback_url: Optional[str] = None

class PaymentInitiateResponse(BaseModel):
    authorization_url: str
    access_code: str
    reference: str
    message: str

class PaymentVerifyResponse(BaseModel):
    status: str
    message: str
    amount: int
    reference: str
    paid_at: Optional[str] = None
    channel: Optional[str] = None
    plan: Optional[str] = None

class PaystackWebhookPayload(BaseModel):
    event: str
    data: Dict[str, Any]

# ==================== PLAYER SCHEMAS ====================
class PlayerBase(BaseModel):
    name: str
    jersey_number: Optional[int] = None
    position: Optional[str] = None
    age: Optional[int] = None
    height: Optional[float] = None
    weight: Optional[float] = None
    dominant_foot: Optional[str] = "right"

class PlayerCreate(PlayerBase):
    pass

class PlayerUpdate(BaseModel):
    name: Optional[str] = None
    jersey_number: Optional[int] = None
    position: Optional[str] = None
    age: Optional[int] = None
    height: Optional[float] = None
    weight: Optional[float] = None
    dominant_foot: Optional[str] = None

class PlayerResponse(PlayerBase):
    id: int
    user_id: int
    overall_rating: float = 0.0
    speed_score: float = 0.0
    technique_score: float = 0.0
    stamina_score: float = 0.0
    decision_score: float = 0.0
    created_at: datetime
    
    class Config:
        from_attributes = True

class PlayerWithStats(PlayerResponse):
    session_count: int = 0
    total_distance: float = 0.0
    avg_max_speed: float = 0.0

# ==================== SESSION SCHEMAS ====================
class SessionBase(BaseModel):
    title: str
    session_type: str = "training"  # match, training, drill
    player_id: int

class SessionCreate(SessionBase):
    pass

class SessionUpdate(BaseModel):
    title: Optional[str] = None
    session_type: Optional[str] = None
    player_id: Optional[int] = None

class SessionResponse(SessionBase):
    id: int
    user_id: int
    date: datetime
    duration_seconds: int = 0
    video_path: Optional[str] = None
    thumbnail_path: Optional[str] = None
    status: str = "pending"  # pending, processing, completed, failed
    
    class Config:
        from_attributes = True

class SessionWithAnalysis(SessionResponse):
    analysis: Optional[Dict[str, Any]] = None
    player_name: Optional[str] = None
    video_url: Optional[str] = None
    thumbnail_url: Optional[str] = None

# ==================== ANALYSIS SCHEMAS ====================
class AnalysisResponse(BaseModel):
    id: int
    session_id: int
    total_distance: float = 0.0
    max_speed: float = 0.0
    avg_speed: float = 0.0
    sprint_count: int = 0
    ball_touches: int = 0
    pass_count: int = 0
    shot_count: int = 0
    tackle_count: int = 0
    
    dribbling_score: float = 0.0
    passing_score: float = 0.0
    shooting_score: float = 0.0
    positioning_score: float = 0.0
    physical_score: float = 0.0
    overall_score: float = 0.0
    
    strengths: List[str] = []
    weaknesses: List[str] = []
    recommendations: List[str] = []
    coaching_notes: Optional[str] = None
    key_moments: List[Dict[str, Any]] = []
    heatmap_data: Dict[str, Any] = {}
    
    created_at: datetime
    
    class Config:
        from_attributes = True

class AnalysisCreate(BaseModel):
    session_id: int
    total_distance: float = 0.0
    max_speed: float = 0.0
    avg_speed: float = 0.0
    sprint_count: int = 0
    ball_touches: int = 0
    pass_count: int = 0
    shot_count: int = 0
    tackle_count: int = 0
    dribbling_score: float = 0.0
    passing_score: float = 0.0
    shooting_score: float = 0.0
    positioning_score: float = 0.0
    physical_score: float = 0.0
    overall_score: float = 0.0
    strengths: List[str] = []
    weaknesses: List[str] = []
    recommendations: List[str] = []
    coaching_notes: Optional[str] = None
    key_moments: List[Dict[str, Any]] = []
    heatmap_data: Dict[str, Any] = {}

# ==================== DASHBOARD SCHEMAS ====================
class DashboardStats(BaseModel):
    total_players: int
    total_sessions: int
    total_videos_analyzed: int
    avg_overall_rating: float
    top_performers: List[PlayerWithStats]
    recent_sessions: List[SessionWithAnalysis]
    weekly_activity: List[Dict[str, Any]]
    skill_distribution: Dict[str, int]

class PerformanceTrend(BaseModel):
    player_id: int
    player_name: str
    dates: List[str]
    overall_scores: List[float]
    physical_scores: List[float]
    technique_scores: List[float]

# ==================== VIDEO UPLOAD SCHEMAS ====================
class VideoUploadResponse(BaseModel):
    session_id: int
    status: str
    message: str
    analysis_preview: Optional[Dict[str, Any]] = None

class VideoStatusResponse(BaseModel):
    session_id: int
    status: str
    progress: float = 0.0
    analysis: Optional[Dict[str, Any]] = None
    error_message: Optional[str] = None

# ==================== DRILL TEMPLATE SCHEMAS ====================
class DrillTemplateBase(BaseModel):
    name: str
    description: str
    category: str
    difficulty: str = "beginner"
    duration_minutes: int
    target_metrics: List[str] = []
    instructions: List[str] = []
    video_demo_url: Optional[str] = None

class DrillTemplateResponse(DrillTemplateBase):
    id: int
    
    class Config:
        from_attributes = True

# ==================== AI FEEDBACK SCHEMAS ====================
class AIFeedbackRequest(BaseModel):
    session_id: int
    question: str  # e.g., "How can I improve my shooting?"

class AIFeedbackResponse(BaseModel):
    answer: str
    related_moments: List[Dict[str, Any]] = []
    suggested_drills: List[str] = []
