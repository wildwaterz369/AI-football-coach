# Deploy to Render

## 1. Click the Blueprint button (or create manually)

If you have a Render account, you can deploy using the `render.yaml` blueprint.

## 2. Manual deployment steps

1. **Create a new Web Service** on Render
   - Build command: `pip install -r requirements.txt`
   - Start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`

2. **Create a PostgreSQL database** (free tier works)
   - Render will automatically inject `DATABASE_URL` into your web service if you link them

3. **Set environment variables** in the Render dashboard:

| Variable | Description | Example |
|----------|-------------|---------|
| `SECRET_KEY` | JWT secret | auto-generated or random string |
| `CORS_ORIGINS` | Frontend URL(s) | `https://your-frontend.onrender.com` or `*` |
| `DATABASE_URL` | Postgres connection | auto-set if linked to DB |
| `STRIPE_SECRET_KEY` | Stripe API key | `sk_test_...` |
| `STRIPE_PUBLIC_KEY` | Stripe publishable key | `pk_test_...` |
| `STRIPE_WEBHOOK_SECRET` | Stripe webhook secret | `whsec_...` |
| `ALIPAY_APPID` | Alipay app ID | |
| `ALIPAY_PRIVATE_KEY` | Alipay private key | |
| `ALIPAY_PUBLIC_KEY` | Alipay public key | |
| `PAYSTACK_SECRET_KEY` | Paystack secret key | `sk_test_...` |
| `PAYSTACK_PUBLIC_KEY` | Paystack public key | `pk_test_...` |
| `AWS_ACCESS_KEY_ID` | S3 access key (optional) | |
| `AWS_SECRET_ACCESS_KEY` | S3 secret key (optional) | |
| `S3_BUCKET_NAME` | S3 bucket name (optional) | |
| `OPENAI_API_KEY` | OpenAI API key (optional) | `sk-...` |

## 3. Files included

- `requirements.txt` — all Python dependencies
- `Procfile` — Render process definition
- `runtime.txt` — Python 3.12
- `render.yaml` — Blueprint for automated infrastructure
- `main.py` — FastAPI entry point

## 4. Post-deploy

After the first deploy, the database tables will be created automatically on startup (`Base.metadata.create_all`).

Health check endpoint: `GET /docs` (Swagger UI) or `GET /` (root).
