"""
Paystack API integration module for the Football AI Coach app.

Supports:
- One-time payments (for plan purchases)
- Subscriptions (recurring billing)
- Webhook verification
- Customer management
"""
import os
import hmac
import hashlib
import requests
from typing import Optional, Dict, Any, List
from datetime import datetime, timedelta

PAYSTACK_SECRET_KEY = os.getenv("PAYSTACK_SECRET_KEY", "")
PAYSTACK_PUBLIC_KEY = os.getenv("PAYSTACK_PUBLIC_KEY", "")
PAYSTACK_BASE_URL = "https://api.paystack.co"

# Plan configurations (in kobo - Nigerian Naira)
# You must create these plans in your Paystack dashboard first
PLAN_CONFIGS = {
    "free": {
        "name": "Free",
        "description": "1 video analysis per month",
        "price": 0,
        "price_display": "₦0",
        "analysis_limit": 1,
        "features": [
            "1 video analysis per month",
            "Basic metrics (distance, speed)",
            "7-day history",
            "Community support"
        ],
        "paystack_plan_code": None,  # Free plan has no Paystack plan
        "popular": False
    },
    "pro": {
        "name": "Pro",
        "description": "Unlimited video analyses for individual coaches",
        "price": 500000,  # ₦5,000
        "price_display": "₦5,000 / month",
        "analysis_limit": 999,
        "features": [
            "Unlimited video analyses",
            "Full technique scores (dribbling, passing, shooting, positioning)",
            "AI coaching notes & recommendations",
            "Heatmap visualization",
            "Progress tracking & trends",
            "Export reports (PDF/CSV)",
            "Priority support"
        ],
        "paystack_plan_code": os.getenv("PAYSTACK_PRO_PLAN_CODE", ""),
        "popular": True
    },
    "team": {
        "name": "Team",
        "description": "For academies and clubs with multiple players",
        "price": 1500000,  # ₦15,000
        "price_display": "₦15,000 / month",
        "analysis_limit": 9999,
        "features": [
            "Everything in Pro",
            "Up to 50 players",
            "Team dashboard & comparisons",
            "Bulk video upload",
            "Custom drill templates",
            "White-label reports",
            "Dedicated account manager"
        ],
        "paystack_plan_code": os.getenv("PAYSTACK_TEAM_PLAN_CODE", ""),
        "popular": False
    }
}


class PaystackClient:
    """HTTP client for Paystack API."""
    
    def __init__(self, secret_key: Optional[str] = None):
        self.secret_key = secret_key or PAYSTACK_SECRET_KEY
        if not self.secret_key:
            raise ValueError("PAYSTACK_SECRET_KEY is required")
        self.headers = {
            "Authorization": f"Bearer {self.secret_key}",
            "Content-Type": "application/json"
        }
    
    def _request(self, method: str, endpoint: str, data: Optional[Dict] = None) -> Dict[str, Any]:
        url = f"{PAYSTACK_BASE_URL}{endpoint}"
        try:
            if method == "GET":
                response = requests.get(url, headers=self.headers, timeout=30)
            elif method == "POST":
                response = requests.post(url, headers=self.headers, json=data, timeout=30)
            elif method == "PUT":
                response = requests.put(url, headers=self.headers, json=data, timeout=30)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")
            
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            return {"status": False, "message": str(e), "data": None}
    
    # ========== CUSTOMER ==========
    def create_customer(self, email: str, first_name: str = "", last_name: str = "", phone: str = "") -> Dict[str, Any]:
        """Create a Paystack customer record."""
        data = {
            "email": email,
            "first_name": first_name,
            "last_name": last_name,
            "phone": phone
        }
        return self._request("POST", "/customer", data)
    
    def fetch_customer(self, email_or_code: str) -> Dict[str, Any]:
        """Fetch a customer by email or customer code."""
        return self._request("GET", f"/customer/{email_or_code}")
    
    # ========== TRANSACTIONS ==========
    def initialize_transaction(self, email: str, amount: int, reference: str,
                                callback_url: Optional[str] = None,
                                plan: Optional[str] = None,
                                metadata: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Initialize a transaction.
        
        Args:
            email: Customer email
            amount: Amount in kobo (smallest currency unit)
            reference: Unique transaction reference
            callback_url: URL to redirect after payment
            plan: Paystack plan code (for subscriptions)
            metadata: Extra data to attach to the transaction
        """
        data = {
            "email": email,
            "amount": amount,
            "reference": reference,
            "metadata": metadata or {}
        }
        if callback_url:
            data["callback_url"] = callback_url
        if plan:
            data["plan"] = plan
        
        return self._request("POST", "/transaction/initialize", data)
    
    def verify_transaction(self, reference: str) -> Dict[str, Any]:
        """Verify a transaction by reference."""
        return self._request("GET", f"/transaction/verify/{reference}")
    
    # ========== SUBSCRIPTIONS ==========
    def create_subscription(self, customer_email: str, plan_code: str,
                             authorization_code: Optional[str] = None) -> Dict[str, Any]:
        """
        Create a new subscription.
        
        Args:
            customer_email: Customer email (must already exist in Paystack)
            plan_code: Paystack plan code
            authorization_code: Card authorization code (optional - Paystack will charge first)
        """
        data = {
            "customer": customer_email,
            "plan": plan_code
        }
        if authorization_code:
            data["authorization"] = authorization_code
        
        return self._request("POST", "/subscription", data)
    
    def fetch_subscription(self, subscription_code: str) -> Dict[str, Any]:
        """Fetch a subscription by code."""
        return self._request("GET", f"/subscription/{subscription_code}")
    
    def list_subscriptions(self, customer_email: Optional[str] = None,
                          plan_code: Optional[str] = None) -> Dict[str, Any]:
        """List subscriptions, optionally filtered by customer or plan."""
        params = {}
        if customer_email:
            params["customer"] = customer_email
        if plan_code:
            params["plan"] = plan_code
        # Paystack list endpoint uses query params, so we build URL manually
        query = "&".join([f"{k}={v}" for k, v in params.items()])
        endpoint = f"/subscription?{query}" if query else "/subscription"
        return self._request("GET", endpoint)
    
    def disable_subscription(self, code: str, token: str) -> Dict[str, Any]:
        """
        Disable a subscription.
        
        Args:
            code: Subscription code
            token: Email token (returned when subscription was created)
        """
        data = {"code": code, "token": token}
        return self._request("POST", "/subscription/disable", data)
    
    def enable_subscription(self, code: str, token: str) -> Dict[str, Any]:
        """Re-enable a disabled subscription."""
        data = {"code": code, "token": token}
        return self._request("POST", "/subscription/enable", data)
    
    # ========== PLANS ==========
    def create_plan(self, name: str, amount: int, interval: str,
                     description: str = "") -> Dict[str, Any]:
        """
        Create a plan on Paystack.
        
        Args:
            name: Plan name
            amount: Amount in kobo
            interval: 'daily', 'weekly', 'monthly', 'quarterly', 'annually'
            description: Plan description
        """
        data = {
            "name": name,
            "amount": amount,
            "interval": interval,
            "description": description
        }
        return self._request("POST", "/plan", data)
    
    def list_plans(self) -> Dict[str, Any]:
        """List all plans on your Paystack account."""
        return self._request("GET", "/plan")


# ========== WEBHOOK VERIFICATION ==========

def verify_paystack_signature(payload: bytes, signature: str, secret_key: Optional[str] = None) -> bool:
    """
    Verify that a webhook payload came from Paystack.
    
    Paystack signs webhooks with HMAC-SHA512 using your secret key.
    """
    key = (secret_key or PAYSTACK_SECRET_KEY).encode("utf-8")
    expected = hmac.new(key, payload, hashlib.sha512).hexdigest()
    return hmac.compare_digest(expected, signature)


# ========== HELPER FUNCTIONS ==========

def get_plan_config(plan_id: str) -> Optional[Dict[str, Any]]:
    """Get configuration for a subscription plan."""
    return PLAN_CONFIGS.get(plan_id)


def get_all_plans() -> List[Dict[str, Any]]:
    """Get all plan configurations as a list."""
    return [
        {"id": k, **v}
        for k, v in PLAN_CONFIGS.items()
    ]


def generate_transaction_reference(user_id: int, plan: str) -> str:
    """Generate a unique transaction reference."""
    timestamp = datetime.utcnow().strftime("%Y%m%d%H%M%S")
    return f"fai_{plan}_{user_id}_{timestamp}_{os.urandom(4).hex()}"


def parse_amount_from_kobo(amount_kobo: int) -> str:
    """Convert kobo amount to human-readable Naira."""
    return f"₦{amount_kobo / 100:,.2f}"


# ========== SUBSCRIPTION STATUS MANAGEMENT ==========

def update_user_subscription(db_user, plan_id: str, status: str = "active",
                                paystack_sub_code: Optional[str] = None,
                                paystack_email_token: Optional[str] = None,
                                next_billing: Optional[datetime] = None) -> None:
    """
    Update a user's subscription fields in the database.
    
    This is a helper that should be called after successful payment or webhook.
    """
    plan_config = get_plan_config(plan_id)
    if not plan_config:
        return
    
    db_user.subscription_plan = plan_id
    db_user.subscription_status = status
    db_user.analysis_limit = plan_config["analysis_limit"]
    
    if paystack_sub_code:
        db_user.paystack_subscription_code = paystack_sub_code
    if paystack_email_token:
        db_user.paystack_email_token = paystack_email_token
    if next_billing:
        db_user.next_billing_date = next_billing
    
    db_user.last_billing_date = datetime.utcnow()


def can_user_upload_video(db_user) -> bool:
    """
    Check if a user can upload a new video based on their subscription.
    
    Returns True if:
    - They have an active paid subscription, OR
    - They are on free plan and haven't exceeded their monthly limit, OR
    - They are in a trial period
    """
    # Check trial
    if db_user.trial_ends_at and db_user.trial_ends_at > datetime.utcnow():
        return True
    
    # Check paid subscription status
    if db_user.subscription_plan in ("pro", "team"):
        if db_user.subscription_status == "active":
            return True
        # Grace period: allow 3 days past due
        if db_user.subscription_status == "past_due" and db_user.next_billing_date:
            grace_period_end = db_user.next_billing_date + timedelta(days=3)
            if datetime.utcnow() < grace_period_end:
                return True
        return False
    
    # Free plan: check monthly limit
    if db_user.analysis_count_monthly < db_user.analysis_limit:
        return True
    
    return False


def get_subscription_tier_features(db_user) -> Dict[str, Any]:
    """Get available features for a user's subscription tier."""
    plan = get_plan_config(db_user.subscription_plan) or get_plan_config("free")
    return {
        "plan": db_user.subscription_plan,
        "status": db_user.subscription_status,
        "analysis_limit": plan["analysis_limit"],
        "analysis_used": db_user.analysis_count_monthly,
        "analysis_remaining": max(0, plan["analysis_limit"] - db_user.analysis_count_monthly),
        "features": plan["features"],
        "can_upload": can_user_upload_video(db_user),
        "has_full_analysis": db_user.subscription_plan in ("pro", "team") and db_user.subscription_status == "active",
        "has_export": db_user.subscription_plan in ("pro", "team"),
        "has_heatmap": db_user.subscription_plan in ("pro", "team"),
        "has_ai_coaching": db_user.subscription_plan in ("pro", "team"),
    }


# ========== DEMO / FALLBACK MODE ==========

if not PAYSTACK_SECRET_KEY:
    print("WARNING: PAYSTACK_SECRET_KEY not set. Payment features will be in demo mode.")
