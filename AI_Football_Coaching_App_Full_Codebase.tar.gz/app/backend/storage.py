import os
import shutil
import boto3
from botocore.exceptions import ClientError
from dotenv import load_dotenv

load_dotenv()

S3_BUCKET = os.getenv("S3_BUCKET")
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
S3_EXPIRES_IN = int(os.getenv("S3_EXPIRES_IN", "3600"))


def use_s3() -> bool:
    """Return True if S3 bucket is configured."""
    return bool(S3_BUCKET)


def _get_s3_client():
    return boto3.client(
        "s3",
        region_name=AWS_REGION,
        aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
        aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
    )


def upload_fileobj(fileobj, key: str) -> str:
    """Upload a file-like object and return the storage key."""
    if not use_s3():
        upload_dir = os.getenv("UPLOAD_DIR", "./uploads")
        path = os.path.join(upload_dir, key)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "wb") as f:
            shutil.copyfileobj(fileobj, f)
        return key

    s3 = _get_s3_client()
    s3.upload_fileobj(fileobj, S3_BUCKET, key)
    return key


def delete_file(key: str) -> None:
    """Delete a file by key."""
    if not key:
        return
    if not use_s3():
        upload_dir = os.getenv("UPLOAD_DIR", "./uploads")
        path = os.path.join(upload_dir, key)
        if os.path.exists(path):
            os.remove(path)
        return

    s3 = _get_s3_client()
    try:
        s3.delete_object(Bucket=S3_BUCKET, Key=key)
    except ClientError:
        pass


def get_presigned_url(key: str) -> str:
    """Generate a presigned URL for reading a file."""
    if not key:
        return ""
    if not use_s3():
        return f"/uploads/{key}"

    s3 = _get_s3_client()
    try:
        url = s3.generate_presigned_url(
            "get_object",
            Params={"Bucket": S3_BUCKET, "Key": key},
            ExpiresIn=S3_EXPIRES_IN,
        )
        return url
    except ClientError:
        return ""


def file_exists(key: str) -> bool:
    """Check if a file exists by key."""
    if not key:
        return False
    if not use_s3():
        upload_dir = os.getenv("UPLOAD_DIR", "./uploads")
        return os.path.exists(os.path.join(upload_dir, key))

    s3 = _get_s3_client()
    try:
        s3.head_object(Bucket=S3_BUCKET, Key=key)
        return True
    except ClientError:
        return False


def download_file(key: str, dest_path: str) -> None:
    """Download a file to a local path."""
    if not key:
        return
    if not use_s3():
        upload_dir = os.getenv("UPLOAD_DIR", "./uploads")
        src = os.path.join(upload_dir, key)
        if os.path.exists(src):
            shutil.copy2(src, dest_path)
        return

    s3 = _get_s3_client()
    s3.download_file(S3_BUCKET, key, dest_path)
