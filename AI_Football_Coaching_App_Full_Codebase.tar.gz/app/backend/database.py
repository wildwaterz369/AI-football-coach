import os
from dotenv import load_dotenv
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Boolean, Text, ForeignKey, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, sessionmaker
import datetime

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./football_ai.db")

# SQLite needs check_same_thread=False; PostgreSQL does not support it
if DATABASE_URL.startswith("sqlite"):
    engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
else:
    engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True)
    hashed_password = Column(String)
    full_name = Column(String)
    role = Column(String, default="coach")  # coach, admin, player
    team_name = Column(String)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    is_active = Column(Boolean, default=True)
    
    # Subscription & billing fields
    subscription_plan = Column(String, default="free")  # free, pro, team
    subscription_status = Column(String, default="inactive")  # active, inactive, cancelled, past_due
    paystack_customer_code = Column(String, default=None)
    paystack_subscription_code = Column(String, default=None)
    paystack_email_token = Column(String, default=None)  # For cancelling subscriptions
    analysis_count_monthly = Column(Integer, default=0)
    analysis_limit = Column(Integer, default=1)  # free=1, pro=999, team=9999
    subscription_expires_at = Column(DateTime, default=None)
    trial_ends_at = Column(DateTime, default=None)
    last_billing_date = Column(DateTime, default=None)
    next_billing_date = Column(DateTime, default=None)
    
    # Payment history (simplified — store last transaction ref)
    last_transaction_ref = Column(String, default=None)
    last_payment_amount = Column(Integer, default=0)  # in kobo/cents
    total_payments = Column(Integer, default=0)  # in kobo/cents
    
    @property
    def is_pro(self):
        return self.subscription_plan in ("pro", "team") and self.subscription_status == "active"

class Player(Base):
    __tablename__ = "players"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    name = Column(String, index=True)
    jersey_number = Column(Integer)
    position = Column(String)  # forward, midfielder, defender, goalkeeper
    age = Column(Integer)
    height = Column(Float)
    weight = Column(Float)
    dominant_foot = Column(String, default="right")  # right, left, both
    profile_image = Column(String)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    # AI-generated metrics (updated after each analysis)
    overall_rating = Column(Float, default=0.0)
    speed_score = Column(Float, default=0.0)
    technique_score = Column(Float, default=0.0)
    stamina_score = Column(Float, default=0.0)
    decision_score = Column(Float, default=0.0)
    
    user = relationship("User", back_populates="players")
    sessions = relationship("Session", back_populates="player")

class Session(Base):
    __tablename__ = "sessions"
    id = Column(Integer, primary_key=True, index=True)
    player_id = Column(Integer, ForeignKey("players.id"))
    user_id = Column(Integer, ForeignKey("users.id"))
    title = Column(String)
    session_type = Column(String)  # match, training, drill
    date = Column(DateTime, default=datetime.datetime.utcnow)
    duration_seconds = Column(Integer, default=0)
    video_path = Column(String)
    thumbnail_path = Column(String)
    status = Column(String, default="pending")  # pending, processing, completed, failed
    
    player = relationship("Player", back_populates="sessions")
    analysis = relationship("Analysis", back_populates="session", uselist=False)

class Analysis(Base):
    __tablename__ = "analyses"
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("sessions.id"))
    
    # Performance metrics
    total_distance = Column(Float, default=0.0)  # meters
    max_speed = Column(Float, default=0.0)  # km/h
    avg_speed = Column(Float, default=0.0)
    sprint_count = Column(Integer, default=0)
    ball_touches = Column(Integer, default=0)
    pass_count = Column(Integer, default=0)
    shot_count = Column(Integer, default=0)
    tackle_count = Column(Integer, default=0)
    
    # Technique scores
    dribbling_score = Column(Float, default=0.0)
    passing_score = Column(Float, default=0.0)
    shooting_score = Column(Float, default=0.0)
    positioning_score = Column(Float, default=0.0)
    physical_score = Column(Float, default=0.0)
    overall_score = Column(Float, default=0.0)
    
    # AI coaching insights
    strengths = Column(JSON, default=list)
    weaknesses = Column(JSON, default=list)
    recommendations = Column(JSON, default=list)
    coaching_notes = Column(Text)
    
    # Key moments (timestamps of important events)
    key_moments = Column(JSON, default=list)
    
    # Heatmap data (simplified as JSON)
    heatmap_data = Column(JSON, default=dict)
    
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    session = relationship("Session", back_populates="analysis")

class DrillTemplate(Base):
    __tablename__ = "drill_templates"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    description = Column(Text)
    category = Column(String)  # technical, physical, tactical, mental
    difficulty = Column(String, default="beginner")  # beginner, intermediate, advanced
    duration_minutes = Column(Integer)
    target_metrics = Column(JSON, default=list)
    instructions = Column(JSON, default=list)
    video_demo_url = Column(String)

class Subscription(Base):
    __tablename__ = "subscriptions"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    plan_id = Column(String, default="free")
    status = Column(String, default="inactive")
    provider = Column(String, default=None)
    provider_subscription_id = Column(String, default=None)
    current_period_start = Column(DateTime, default=None)
    current_period_end = Column(DateTime, default=None)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow)
    cancelled_at = Column(DateTime, default=None)

# Payment log (for audit trail)
class PaymentLog(Base):
    __tablename__ = "payment_logs"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    event_type = Column(String)  # charge.success, subscription.create, etc.
    paystack_ref = Column(String)
    paystack_event_id = Column(String)
    amount = Column(Integer, default=0)  # in kobo
    status = Column(String)
    payload = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

User.players = relationship("Player", order_by=Player.id, back_populates="user")
User.payment_logs = relationship("PaymentLog", order_by=PaymentLog.id)

Base.metadata.create_all(bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
