from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Form, status, BackgroundTasks, Request, Header
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordRequestForm
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
from typing import List, Optional
import os
import shutil
import uuid
import json
import tempfile
import imageio.v3 as iio
from PIL import Image, ImageDraw, ImageFont
from datetime import datetime, timedelta
import hmac
import hashlib

from dotenv import load_dotenv
load_dotenv()

from database import get_db, Session as DBSession, SessionLocal, Player, Analysis, DrillTemplate, Subscription
from database import User as DBUser
from models import (
    UserCreate, UserResponse, UserLogin, Token,
    PlayerCreate, PlayerUpdate, PlayerResponse, PlayerWithStats,
    SessionCreate, SessionUpdate, SessionResponse, SessionWithAnalysis,
    AnalysisResponse, AnalysisCreate,
    DashboardStats, PerformanceTrend,
    VideoUploadResponse, VideoStatusResponse,
    DrillTemplateResponse, DrillTemplateBase,
    AIFeedbackRequest, AIFeedbackResponse,
    SubscriptionPlan
)
from auth import create_user, authenticate_user, create_access_token, get_current_active_user, get_password_hash
from ai_engine import FootballAIEngine, generate_sample_analysis
import storage as storage_module

app = FastAPI(
    title="AI Football Coach API",
    description="AI-powered football coaching platform with video analysis",
    version="1.0.0"
)

# CORS for frontend
_cors_origins = os.getenv("CORS_ORIGINS", "http://localhost:5173,http://localhost:3000")
if _cors_origins == "*":
    allow_origins = ["*"]
else:
    allow_origins = [o.strip() for o in _cors_origins.split(",") if o.strip()]

app.add_middleware(
    CORSMiddleware,
    allow_origins=allow_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global error handler middleware
@app.middleware("http")
async def catch_all_exceptions(request: Request, call_next):
    try:
        return await call_next(request)
    except HTTPException:
        raise
    except Exception as e:
        import traceback
        traceback.print_exc()
        return JSONResponse(
            status_code=500,
            content={"detail": "Internal server error. The team has been notified."}
        )

# Static files for uploads (local fallback only)
if not storage_module.use_s3():
    _upload_dir = os.getenv("UPLOAD_DIR", "./uploads")
    if os.path.exists(_upload_dir):
        app.mount("/uploads", StaticFiles(directory=_upload_dir), name="uploads")

# Upload directories
UPLOAD_DIR = os.getenv("UPLOAD_DIR", "./uploads")
THUMBNAIL_DIR = os.path.join(UPLOAD_DIR, "thumbnails")
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(THUMBNAIL_DIR, exist_ok=True)

# ====== Payment & Subscription Config ======
STRIPE_SECRET_KEY = os.environ.get("STRIPE_SECRET_KEY", "")
STRIPE_WEBHOOK_SECRET = os.environ.get("STRIPE_WEBHOOK_SECRET", "")
ALIPAY_APPID = os.environ.get("ALIPAY_APPID", "")
ALIPAY_PRIVATE_KEY = os.environ.get("ALIPAY_PRIVATE_KEY", "")
ALIPAY_PUBLIC_KEY = os.environ.get("ALIPAY_PUBLIC_KEY", "")
ALIPAY_NOTIFY_URL = os.environ.get("ALIPAY_NOTIFY_URL", "")

try:
    import stripe
    stripe.api_key = STRIPE_SECRET_KEY
except Exception:
    stripe = None

# In-memory plan catalogue (easily extensible)
PLAN_CATALOGUE = {
    "free": {
        "id": "free",
        "name": "Free",
        "price_monthly_cny": 0,
        "analysis_quota": 3,
        "features": ["3 AI analyses per month", "Basic stats", "Video upload"]
    },
    "pro": {
        "id": "pro",
        "name": "Pro",
        "price_monthly_cny": 68,
        "analysis_quota": 30,
        "features": ["30 AI analyses per month", "Advanced stats & heatmaps", "Priority processing", "Team support"]
    },
    "elite": {
        "id": "elite",
        "name": "Elite",
        "price_monthly_cny": 198,
        "analysis_quota": 9999,
        "features": ["Unlimited AI analyses", "Full tactical report", "API access", "1-on-1 coaching review"]
    }
}


def get_active_subscription(db: Session, user_id: int) -> Optional[Subscription]:
    """Return the latest active subscription for a user, or None."""
    return db.query(Subscription).filter(
        Subscription.user_id == user_id,
        Subscription.status.in_(["active", "trial"]),
        (Subscription.current_period_end == None) | (Subscription.current_period_end > datetime.utcnow())
    ).order_by(Subscription.current_period_end.desc()).first()


def get_user_effective_plan(db: Session, user_id: int) -> dict:
    """Return the effective plan dict for the user."""
    sub = get_active_subscription(db, user_id)
    if sub and sub.plan_id in PLAN_CATALOGUE:
        return PLAN_CATALOGUE[sub.plan_id]
    return PLAN_CATALOGUE["free"]


def get_user_analysis_count_this_month(db: Session, user_id: int) -> int:
    """Count completed analyses created this month for the user."""
    now = datetime.utcnow()
    start_of_month = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    return db.query(Analysis).join(DBSession).filter(
        DBSession.user_id == user_id,
        Analysis.created_at >= start_of_month
    ).count()


async def check_subscription_upload_permission(
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    """Dependency: block upload if quota exceeded."""
    plan = get_user_effective_plan(db, current_user.id)
    used = get_user_analysis_count_this_month(db, current_user.id)
    if used >= plan["analysis_quota"]:
        raise HTTPException(
            status_code=402,
            detail="Analysis quota exceeded. Please upgrade your plan to continue uploading."
        )

# ============== HEALTH CHECK ==============
@app.get("/")
async def root():
    return {"message": "AI Football Coach API", "version": "1.0.0", "status": "running"}

@app.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": datetime.utcnow()}

# ============== AUTH ROUTES ==============
@app.post("/auth/register", response_model=UserResponse)
async def register(user: UserCreate, db: Session = Depends(get_db)):
    db_user = db.query(DBUser).filter(DBUser.email == user.email).first()
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    new_user = create_user(db, user)
    return new_user

@app.post("/auth/login", response_model=Token)
async def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = authenticate_user(db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token = create_access_token(data={"sub": user.email})
    return {"access_token": access_token, "token_type": "bearer"}

@app.get("/auth/me", response_model=UserResponse)
async def get_me(current_user: DBUser = Depends(get_current_active_user)):
    return current_user

@app.put("/auth/me", response_model=UserResponse)
async def update_me(
    full_name: Optional[str] = Form(None),
    team_name: Optional[str] = Form(None),
    current_password: Optional[str] = Form(None),
    new_password: Optional[str] = Form(None),
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    """Update current user's profile. Optionally change password if current_password is provided."""
    if full_name is not None:
        current_user.full_name = full_name
    if team_name is not None:
        current_user.team_name = team_name
    if new_password:
        if not current_password:
            raise HTTPException(status_code=400, detail="Current password required to set new password")
        from auth import verify_password
        if not verify_password(current_password, current_user.hashed_password):
            raise HTTPException(status_code=400, detail="Current password is incorrect")
        current_user.hashed_password = get_password_hash(new_password)
    db.commit()
    db.refresh(current_user)
    return current_user

# JSON-based profile update (frontend expects PUT /auth/profile with JSON)
from pydantic import BaseModel as PydanticBaseModel
class ProfileUpdateRequest(PydanticBaseModel):
    full_name: Optional[str] = None
    team_name: Optional[str] = None
    current_password: Optional[str] = None
    new_password: Optional[str] = None

@app.put("/auth/profile")
async def update_profile_json(
    request: ProfileUpdateRequest,
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    """Update current user's profile via JSON (frontend compatibility)."""
    updated = False
    if request.full_name is not None:
        current_user.full_name = request.full_name
        updated = True
    if request.team_name is not None:
        current_user.team_name = request.team_name
        updated = True
    if request.new_password:
        if not request.current_password:
            raise HTTPException(status_code=400, detail="Current password required to set new password")
        from auth import verify_password
        if not verify_password(request.current_password, current_user.hashed_password):
            raise HTTPException(status_code=400, detail="Current password is incorrect")
        current_user.hashed_password = get_password_hash(request.new_password)
        updated = True
    if updated:
        db.commit()
        db.refresh(current_user)
    return {
        "message": "Profile updated successfully",
        "user": {
            "id": current_user.id,
            "email": current_user.email,
            "full_name": current_user.full_name,
            "role": current_user.role,
            "team_name": current_user.team_name
        }
    }

# ============== SUBSCRIPTION ROUTES ==============
@app.get("/subscription")
async def get_subscription_status(
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    """Return current user's subscription status (frontend expects /subscription)."""
    return await get_my_subscription(db, current_user)

@app.get("/subscription/plans")
async def get_plans():
    """Return available subscription plans."""
    return {"plans": list(PLAN_CATALOGUE.values())}

@app.get("/subscription/me")
async def get_my_subscription(
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    """Return current user's subscription status and quota in frontend-expected format."""
    plan = get_user_effective_plan(db, current_user.id)
    used = get_user_analysis_count_this_month(db, current_user.id)
    quota = plan["analysis_quota"]
    percent_used = round((used / quota) * 100, 1) if quota > 0 else 0
    sub = get_active_subscription(db, current_user.id)
    
    active_subscription = None
    if sub:
        active_subscription = {
            "id": sub.id,
            "user_id": sub.user_id,
            "plan_id": sub.plan_id,
            "status": sub.status,
            "current_period_start": sub.current_period_start.isoformat() if sub.current_period_start else None,
            "current_period_end": sub.current_period_end.isoformat() if sub.current_period_end else None,
            "stripe_subscription_id": sub.provider_subscription_id,
            "stripe_customer_id": None,
            "created_at": sub.created_at.isoformat() if sub.created_at else None,
            "updated_at": sub.updated_at.isoformat() if sub.updated_at else None,
            "plan": {
                "id": plan["id"],
                "name": plan["name"],
                "price_monthly_cny": plan["price_monthly_cny"],
                "analysis_quota": plan["analysis_quota"],
                "features": plan["features"]
            }
        }
    
    return {
        "current_plan": {
            "id": plan["id"],
            "name": plan["name"],
            "price_monthly_cny": plan["price_monthly_cny"],
            "analysis_quota": plan["analysis_quota"],
            "features": plan["features"]
        },
        "active_subscription": active_subscription,
        "analysis_used": used,
        "analysis_quota": quota,
        "percent_used": percent_used,
        "has_quota": used < quota
    }

@app.get("/subscription/payments")
async def get_payment_history(
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    """Return payment history for the current user."""
    from database import PaymentLog
    logs = db.query(PaymentLog).filter(PaymentLog.user_id == current_user.id).order_by(PaymentLog.created_at.desc()).all()
    result = []
    for log in logs:
        result.append({
            "id": log.id,
            "date": log.created_at.isoformat() if log.created_at else None,
            "amount": log.amount / 100,  # convert cents to currency units
            "status": log.status,
            "plan": log.payload.get("plan", "unknown") if log.payload else "unknown",
            "method": log.payload.get("method", "card") if log.payload else "card",
            "reference": log.paystack_ref or ""
        })
    return {"payments": result}

@app.post("/subscription/checkout")
async def create_subscription_checkout(
    plan_id: str = Form(...),
    payment_method: str = Form(...),
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    """Create a checkout session for subscription (Stripe or Alipay)."""
    if plan_id not in PLAN_CATALOGUE or plan_id == "free":
        raise HTTPException(status_code=400, detail="Invalid plan")
    
    if payment_method == "stripe":
        return await init_stripe_subscription(plan_id, db, current_user)
    elif payment_method == "alipay":
        return await init_alipay_subscription(plan_id, db, current_user)
    else:
        raise HTTPException(status_code=400, detail="Unsupported payment method")

@app.post("/subscription/resume")
async def resume_subscription(
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    """Resume a cancelled subscription."""
    sub = db.query(Subscription).filter(
        Subscription.user_id == current_user.id,
        Subscription.status == "cancelled"
    ).order_by(Subscription.current_period_end.desc()).first()
    
    if not sub:
        raise HTTPException(status_code=404, detail="No cancelled subscription found")
    
    if sub.provider == "stripe" and stripe:
        try:
            stripe.Subscription.modify(sub.provider_subscription_id, cancel_at_period_end=False)
        except Exception as e:
            print(f"Stripe resume error: {e}")
    
    sub.status = "active"
    sub.cancelled_at = None
    db.commit()
    db.refresh(sub)
    
    plan = get_user_effective_plan(db, current_user.id)
    return {
        "message": "Subscription resumed successfully",
        "subscription": {
            "id": sub.id,
            "user_id": sub.user_id,
            "plan_id": sub.plan_id,
            "status": sub.status,
            "current_period_start": sub.current_period_start.isoformat() if sub.current_period_start else None,
            "current_period_end": sub.current_period_end.isoformat() if sub.current_period_end else None,
            "stripe_subscription_id": sub.provider_subscription_id,
            "stripe_customer_id": None,
            "created_at": sub.created_at.isoformat() if sub.created_at else None,
            "updated_at": sub.updated_at.isoformat() if sub.updated_at else None,
            "plan": {
                "id": plan["id"],
                "name": plan["name"],
                "price_monthly_cny": plan["price_monthly_cny"],
                "analysis_quota": plan["analysis_quota"],
                "features": plan["features"]
            }
        }
    }


@app.post("/subscription/stripe/init")
async def init_stripe_subscription(
    plan_id: str = Form(...),
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    """Create a Stripe Checkout Session for subscription."""
    if not stripe:
        raise HTTPException(status_code=503, detail="Stripe integration not configured")
    if plan_id not in PLAN_CATALOGUE or plan_id == "free":
        raise HTTPException(status_code=400, detail="Invalid plan")
    
    price_cny = PLAN_CATALOGUE[plan_id]["price_monthly_cny"]
    # For demo, create a simple checkout session using Stripe
    try:
        checkout_session = stripe.checkout.Session.create(
            line_items=[{
                "price_data": {
                    "currency": "cny",
                    "product_data": {"name": f"FootballPro AI - {PLAN_CATALOGUE[plan_id]['name']} Plan"},
                    "unit_amount": price_cny * 100,  # cents
                    "recurring": {"interval": "month"}
                },
                "quantity": 1,
            }],
            mode="subscription",
            success_url=os.environ.get("FRONTEND_URL", "http://localhost:5173") + "/payment/success?session_id={CHECKOUT_SESSION_ID}",
            cancel_url=os.environ.get("FRONTEND_URL", "http://localhost:5173") + "/payment/cancel",
            client_reference_id=str(current_user.id),
            metadata={"plan_id": plan_id, "user_id": str(current_user.id)}
        )
        return {"checkout_url": checkout_session.url, "session_id": checkout_session.id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Stripe error: {str(e)}")

@app.post("/subscription/stripe/verify")
async def verify_stripe_subscription(
    session_id: str = Form(...),
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    """Verify and record a Stripe subscription after checkout."""
    if not stripe:
        raise HTTPException(status_code=503, detail="Stripe integration not configured")
    try:
        checkout_session = stripe.checkout.Session.retrieve(session_id)
        if checkout_session.client_reference_id != str(current_user.id):
            raise HTTPException(status_code=403, detail="Session mismatch")
        if checkout_session.payment_status != "paid":
            return {"status": "pending", "message": "Payment not yet confirmed"}
        
        plan_id = checkout_session.metadata.get("plan_id", "pro")
        
        # Check if existing subscription record
        existing = db.query(Subscription).filter(Subscription.user_id == current_user.id).first()
        if existing:
            existing.plan_id = plan_id
            existing.status = "active"
            existing.provider = "stripe"
            existing.provider_subscription_id = checkout_session.subscription
            existing.current_period_start = datetime.utcnow()
            existing.current_period_end = datetime.utcnow() + timedelta(days=30)
            existing.updated_at = datetime.utcnow()
        else:
            sub = Subscription(
                user_id=current_user.id,
                plan_id=plan_id,
                status="active",
                provider="stripe",
                provider_subscription_id=checkout_session.subscription,
                current_period_start=datetime.utcnow(),
                current_period_end=datetime.utcnow() + timedelta(days=30)
            )
            db.add(sub)
        db.commit()
        return {"status": "success", "plan_id": plan_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Verification error: {str(e)}")

@app.post("/subscription/webhook/stripe")
async def stripe_webhook(request: Request, db: Session = Depends(get_db)):
    """Handle Stripe webhook events."""
    if not stripe:
        raise HTTPException(status_code=503, detail="Stripe not configured")
    payload = await request.body()
    sig_header = request.headers.get("stripe-signature", "")
    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, STRIPE_WEBHOOK_SECRET
        )
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid signature")
    
    if event["type"] == "invoice.payment_succeeded":
        sub_obj = event["data"]["object"]
        customer = sub_obj.get("customer", "")
        # Find subscription by provider id
        sub = db.query(Subscription).filter(Subscription.provider_subscription_id == sub_obj.get("subscription", "")).first()
        if sub:
            sub.status = "active"
            sub.current_period_end = datetime.utcnow() + timedelta(days=30)
            db.commit()
    elif event["type"] == "customer.subscription.deleted":
        sub_obj = event["data"]["object"]
        sub = db.query(Subscription).filter(Subscription.provider_subscription_id == sub_obj.get("id", "")).first()
        if sub:
            sub.status = "cancelled"
            sub.cancelled_at = datetime.utcnow()
            db.commit()
    
    return {"status": "received"}

@app.post("/subscription/alipay/init")
async def init_alipay_subscription(
    plan_id: str = Form(...),
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    """Return Alipay payment URL (demo scaffold)."""
    if plan_id not in PLAN_CATALOGUE or plan_id == "free":
        raise HTTPException(status_code=400, detail="Invalid plan")
    
    # In production, integrate with Alipay SDK (e.g., alipay-sdk-python)
    # For demo, return a placeholder indicating where to integrate
    return {
        "message": "Alipay integration placeholder. Integrate with alipay-sdk-python for production.",
        "plan_id": plan_id,
        "price_cny": PLAN_CATALOGUE[plan_id]["price_monthly_cny"],
        "user_id": current_user.id,
        "notify_url": ALIPAY_NOTIFY_URL
    }

@app.post("/subscription/alipay/notify")
async def alipay_notify(request: Request, db: Session = Depends(get_db)):
    """Handle Alipay async notification (demo scaffold)."""
    # In production, verify signature using Alipay SDK and update subscription
    body = await request.body()
    return {"status": "received", "note": "Implement Alipay SDK verification in production"}

@app.post("/subscription/cancel")
async def cancel_subscription(
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    """Cancel current subscription (downgrades to free at period end)."""
    sub = get_active_subscription(db, current_user.id)
    if not sub:
        return {"status": "no_active_subscription"}
    
    if sub.provider == "stripe" and stripe:
        try:
            stripe.Subscription.modify(sub.provider_subscription_id, cancel_at_period_end=True)
        except Exception:
            pass
    
    sub.status = "cancelled"
    sub.cancelled_at = datetime.utcnow()
    db.commit()
    return {"status": "cancelled", "message": "Subscription will remain active until period end"}

# ============== PLAYER ROUTES ==============
@app.post("/players", response_model=PlayerResponse)
async def create_player(
    player: PlayerCreate,
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    db_player = Player(
        user_id=current_user.id,
        name=player.name,
        jersey_number=player.jersey_number,
        position=player.position,
        age=player.age,
        height=player.height,
        weight=player.weight,
        dominant_foot=player.dominant_foot
    )
    db.add(db_player)
    db.commit()
    db.refresh(db_player)
    return db_player

@app.get("/players", response_model=List[PlayerWithStats])
async def get_players(
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    players = db.query(Player).filter(Player.user_id == current_user.id).all()
    result = []
    for player in players:
        sessions = db.query(DBSession).filter(DBSession.player_id == player.id).all()
        session_count = len(sessions)
        total_distance = 0.0
        max_speeds = []
        for session in sessions:
            analysis = db.query(Analysis).filter(Analysis.session_id == session.id).first()
            if analysis:
                total_distance += analysis.total_distance or 0
                max_speeds.append(analysis.max_speed or 0)
        avg_max_speed = sum(max_speeds) / len(max_speeds) if max_speeds else 0.0
        result.append(PlayerWithStats(
            id=player.id,
            user_id=player.user_id,
            name=player.name,
            jersey_number=player.jersey_number,
            position=player.position,
            age=player.age,
            height=player.height,
            weight=player.weight,
            dominant_foot=player.dominant_foot,
            overall_rating=player.overall_rating,
            speed_score=player.speed_score,
            technique_score=player.technique_score,
            stamina_score=player.stamina_score,
            decision_score=player.decision_score,
            created_at=player.created_at,
            session_count=session_count,
            total_distance=round(total_distance, 1),
            avg_max_speed=round(avg_max_speed, 1)
        ))
    return result

@app.get("/players/{player_id}", response_model=PlayerWithStats)
async def get_player(
    player_id: int,
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    player = db.query(Player).filter(Player.id == player_id, Player.user_id == current_user.id).first()
    if not player:
        raise HTTPException(status_code=404, detail="Player not found")
    
    # Calculate stats
    sessions = db.query(DBSession).filter(DBSession.player_id == player_id).all()
    session_count = len(sessions)
    total_distance = 0.0
    max_speeds = []
    
    for session in sessions:
        analysis = db.query(Analysis).filter(Analysis.session_id == session.id).first()
        if analysis:
            total_distance += analysis.total_distance or 0
            max_speeds.append(analysis.max_speed or 0)
    
    avg_max_speed = sum(max_speeds) / len(max_speeds) if max_speeds else 0.0
    
    return PlayerWithStats(
        id=player.id,
        user_id=player.user_id,
        name=player.name,
        jersey_number=player.jersey_number,
        position=player.position,
        age=player.age,
        height=player.height,
        weight=player.weight,
        dominant_foot=player.dominant_foot,
        overall_rating=player.overall_rating,
        speed_score=player.speed_score,
        technique_score=player.technique_score,
        stamina_score=player.stamina_score,
        decision_score=player.decision_score,
        created_at=player.created_at,
        session_count=session_count,
        total_distance=round(total_distance, 1),
        avg_max_speed=round(avg_max_speed, 1)
    )

@app.put("/players/{player_id}", response_model=PlayerResponse)
async def update_player(
    player_id: int,
    player_update: PlayerUpdate,
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    player = db.query(Player).filter(Player.id == player_id, Player.user_id == current_user.id).first()
    if not player:
        raise HTTPException(status_code=404, detail="Player not found")
    
    for field, value in player_update.dict(exclude_unset=True).items():
        setattr(player, field, value)
    
    db.commit()
    db.refresh(player)
    return player

@app.delete("/players/{player_id}")
async def delete_player(
    player_id: int,
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    player = db.query(Player).filter(Player.id == player_id, Player.user_id == current_user.id).first()
    if not player:
        raise HTTPException(status_code=404, detail="Player not found")
    db.delete(player)
    db.commit()
    return {"message": "Player deleted"}

# ============== SESSION ROUTES ==============
@app.post("/sessions", response_model=SessionResponse)
async def create_session(
    session: SessionCreate,
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    player = db.query(Player).filter(Player.id == session.player_id, Player.user_id == current_user.id).first()
    if not player:
        raise HTTPException(status_code=404, detail="Player not found")
    
    db_session = DBSession(
        player_id=session.player_id,
        user_id=current_user.id,
        title=session.title,
        session_type=session.session_type
    )
    db.add(db_session)
    db.commit()
    db.refresh(db_session)
    return db_session

@app.get("/sessions", response_model=List[SessionWithAnalysis])
async def get_sessions(
    player_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    query = db.query(DBSession).filter(DBSession.user_id == current_user.id)
    if player_id:
        query = query.filter(DBSession.player_id == player_id)
    sessions = query.order_by(DBSession.date.desc()).all()
    
    result = []
    for session in sessions:
        analysis = db.query(Analysis).filter(Analysis.session_id == session.id).first()
        player = db.query(Player).filter(Player.id == session.player_id).first()
        
        session_dict = {
            "id": session.id,
            "player_id": session.player_id,
            "user_id": session.user_id,
            "title": session.title,
            "session_type": session.session_type,
            "date": session.date,
            "duration_seconds": session.duration_seconds,
            "video_path": session.video_path,
            "thumbnail_path": session.thumbnail_path,
            "status": session.status,
            "analysis": {k: v for k, v in analysis.__dict__.items() if not k.startswith('_')} if analysis else None,
            "player_name": player.name if player else None
        }
        result.append(session_dict)
    
    return result

@app.get("/sessions/{session_id}", response_model=SessionWithAnalysis)
async def get_session(
    session_id: int,
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    session = db.query(DBSession).filter(DBSession.id == session_id, DBSession.user_id == current_user.id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    analysis = db.query(Analysis).filter(Analysis.session_id == session.id).first()
    player = db.query(Player).filter(Player.id == session.player_id).first()
    
    return {
        "id": session.id,
        "player_id": session.player_id,
        "user_id": session.user_id,
        "title": session.title,
        "session_type": session.session_type,
        "date": session.date,
        "duration_seconds": session.duration_seconds,
        "video_path": session.video_path,
        "thumbnail_path": session.thumbnail_path,
        "status": session.status,
        "analysis": {k: v for k, v in analysis.__dict__.items() if not k.startswith('_')} if analysis else None,
        "player_name": player.name if player else None
    }

# ============== UPDATE SESSION ==============
@app.put("/sessions/{session_id}", response_model=SessionWithAnalysis)
async def update_session(
    session_id: int,
    session_update: SessionUpdate,
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    session = db.query(DBSession).filter(DBSession.id == session_id, DBSession.user_id == current_user.id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    # Validate player_id if provided
    if session_update.player_id is not None:
        player = db.query(Player).filter(Player.id == session_update.player_id, Player.user_id == current_user.id).first()
        if not player:
            raise HTTPException(status_code=404, detail="Player not found")
        session.player_id = session_update.player_id
    
    if session_update.title is not None:
        session.title = session_update.title
    if session_update.session_type is not None:
        session.session_type = session_update.session_type
    
    db.commit()
    db.refresh(session)
    
    analysis = db.query(Analysis).filter(Analysis.session_id == session.id).first()
    player = db.query(Player).filter(Player.id == session.player_id).first()
    
    return {
        "id": session.id,
        "player_id": session.player_id,
        "user_id": session.user_id,
        "title": session.title,
        "session_type": session.session_type,
        "date": session.date,
        "duration_seconds": session.duration_seconds,
        "video_path": session.video_path,
        "thumbnail_path": session.thumbnail_path,
        "status": session.status,
        "analysis": {k: v for k, v in analysis.__dict__.items() if not k.startswith('_')} if analysis else None,
        "player_name": player.name if player else None
    }

# ============== DELETE SESSION ==============
@app.delete("/sessions/{session_id}")
async def delete_session(
    session_id: int,
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    session = db.query(DBSession).filter(DBSession.id == session_id, DBSession.user_id == current_user.id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    # Delete associated analysis
    analysis = db.query(Analysis).filter(Analysis.session_id == session_id).first()
    if analysis:
        db.delete(analysis)
    
    # Delete video and thumbnail from storage
    if session.video_path:
        storage_module.delete_file(session.video_path)
    if session.thumbnail_path:
        storage_module.delete_file(session.thumbnail_path)
    
    db.delete(session)
    db.commit()
    return {"message": "Session deleted"}

# ============== REANALYZE SESSION ==============
@app.post("/sessions/{session_id}/reanalyze", response_model=VideoUploadResponse)
async def reanalyze_session(
    session_id: int,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user),
    _: None = Depends(check_subscription_upload_permission)
):
    session = db.query(DBSession).filter(DBSession.id == session_id, DBSession.user_id == current_user.id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    session.status = "processing"
    db.commit()
    
    # Delete old analysis
    analysis = db.query(Analysis).filter(Analysis.session_id == session_id).first()
    if analysis:
        db.delete(analysis)
        db.commit()
    
    # Start reanalysis in background
    if session.video_path and storage_module.file_exists(session.video_path):
        background_tasks.add_task(process_video_analysis, session.id, session.video_path)
    else:
        # If no video file, generate sample analysis
        background_tasks.add_task(process_video_analysis, session.id, "")
    
    return VideoUploadResponse(
        session_id=session.id,
        status="processing",
        message="Reanalysis started"
    )

# ============== THUMBNAIL GENERATION ==============
def generate_thumbnail(video_full_path: str, thumbnail_dir: str) -> str:
    """Extract a frame from the video and save it as a thumbnail."""
    try:
        # Get video properties
        meta = iio.immeta(video_full_path)
        n_frames = meta.get("nframes", None)
        
        # If n_frames is not available, estimate from duration and fps
        if n_frames is None or n_frames == float('inf'):
            duration = meta.get("duration", 0)
            fps = meta.get("fps", 30)
            if duration and fps:
                n_frames = int(duration * fps)
            else:
                n_frames = 100  # fallback
        
        # Pick a frame ~30% into the video (at least frame 1)
        target_idx = max(1, int(n_frames * 0.3))
        
        # Read the target frame
        frame = iio.imread(video_full_path, index=target_idx)
        
        # Resize to a standard thumbnail size (320x180)
        img = Image.fromarray(frame)
        img.thumbnail((320, 320))  # preserve aspect ratio
        
        # Save as JPEG
        thumbnail_filename = f"{uuid.uuid4()}.jpg"
        thumbnail_path = os.path.join(thumbnail_dir, thumbnail_filename)
        img.save(thumbnail_path, "JPEG", quality=85)
        
        return thumbnail_filename
    except Exception as e:
        # Fallback: generate a simple placeholder thumbnail
        try:
            thumbnail_filename = f"{uuid.uuid4()}.jpg"
            thumbnail_path = os.path.join(thumbnail_dir, thumbnail_filename)
            
            img = Image.new("RGB", (320, 180), color=(30, 41, 59))
            draw = ImageDraw.Draw(img)
            
            # Try to use a font, fall back to default
            try:
                font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 20)
            except Exception:
                font = ImageFont.load_default()
            
            text = "Video"
            bbox = draw.textbbox((0, 0), text, font=font)
            text_width = bbox[2] - bbox[0]
            text_height = bbox[3] - bbox[1]
            x = (320 - text_width) // 2
            y = (180 - text_height) // 2
            draw.text((x, y), text, fill=(255, 255, 255), font=font)
            
            img.save(thumbnail_path, "JPEG", quality=85)
            return thumbnail_filename
        except Exception:
            return None

# ============== VIDEO UPLOAD & ANALYSIS ==============
@app.post("/upload-video", response_model=VideoUploadResponse)
async def upload_video(
    background_tasks: BackgroundTasks,
    title: str = Form(...),
    file: UploadFile = File(...),
    player_id: Optional[int] = Form(None),
    description: Optional[str] = Form(None),
    session_type: str = Form("training"),
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user),
    _: None = Depends(check_subscription_upload_permission)
):
    # Validate player if provided
    if player_id:
        player = db.query(Player).filter(Player.id == player_id, Player.user_id == current_user.id).first()
        if not player:
            raise HTTPException(status_code=404, detail="Player not found")
    
    # Create session
    db_session = DBSession(
        player_id=player_id,
        user_id=current_user.id,
        title=title,
        session_type=session_type,
        status="processing"
    )
    db.add(db_session)
    db.commit()
    db.refresh(db_session)
    
    # Save video file to storage
    file_ext = file.filename.split('.')[-1] if '.' in file.filename else 'mp4'
    video_filename = f"{uuid.uuid4()}.{file_ext}"
    file.file.seek(0)
    storage_module.upload_fileobj(file.file, video_filename)
    
    db_session.video_path = video_filename
    db.commit()
    
    # Start analysis in background
    background_tasks.add_task(process_video_analysis, db_session.id, video_filename)
    
    return VideoUploadResponse(
        session_id=db_session.id,
        status="processing",
        message="Video uploaded and analysis started"
    )

def process_video_analysis(session_id: int, video_path: str):
    """Background task to process video with AI engine."""
    db = SessionLocal()
    try:
        # In production, this runs the full AI pipeline
        # For demo, we generate realistic sample analysis
        ai_engine = FootballAIEngine()
        
        full_video_path = os.path.join(UPLOAD_DIR, video_path) if video_path else ""
        
        # Check if video is valid
        if os.path.exists(full_video_path) and os.path.getsize(full_video_path) > 1000:
            try:
                results = ai_engine.analyze_video(full_video_path)
            except Exception as e:
                # Fallback to sample analysis for demo
                results = generate_sample_analysis()
        else:
            results = generate_sample_analysis()
        
        # Update session with results
        session = db.query(DBSession).filter(DBSession.id == session_id).first()
        if session:
            session.status = "completed"
            session.duration_seconds = int(results["metrics"]["duration"])
            
            # Create analysis record
            analysis = Analysis(
                session_id=session_id,
                total_distance=results["metrics"]["total_distance"],
                max_speed=results["metrics"]["max_speed"],
                avg_speed=results["metrics"]["avg_speed"],
                sprint_count=results["metrics"]["sprint_count"],
                ball_touches=results["metrics"]["ball_touches"],
                pass_count=results["metrics"]["pass_count"],
                shot_count=results["metrics"]["shot_count"],
                tackle_count=results["metrics"]["tackle_count"],
                dribbling_score=results["technique_scores"]["dribbling"],
                passing_score=results["technique_scores"]["passing"],
                shooting_score=results["technique_scores"]["shooting"],
                positioning_score=results["technique_scores"]["positioning"],
                physical_score=results["technique_scores"]["physical"],
                overall_score=results["technique_scores"]["overall"],
                strengths=results["strengths"],
                weaknesses=results["weaknesses"],
                recommendations=results["recommendations"],
                coaching_notes=results["coaching_notes"],
                key_moments=results["key_moments"],
                heatmap_data=results["heatmap"]
            )
            db.add(analysis)
            
            # Update player ratings
            player = db.query(Player).filter(Player.id == session.player_id).first()
            if player:
                def update_score(existing, new):
                    if existing == 0:
                        return new
                    return round(existing * 0.7 + new * 0.3, 1)
                # Update with weighted average (new session 30%, existing 70%)
                player.overall_rating = update_score(player.overall_rating, results["technique_scores"]["overall"])
                player.speed_score = update_score(player.speed_score, results["technique_scores"]["physical"])
                player.technique_score = update_score(player.technique_score, results["technique_scores"]["dribbling"])
                player.stamina_score = update_score(player.stamina_score, results["technique_scores"]["physical"])
                player.decision_score = update_score(player.decision_score, results["technique_scores"]["positioning"])
            
            # Generate thumbnail
            thumbnail_filename = None
            if os.path.exists(full_video_path) and os.path.getsize(full_video_path) > 1000:
                thumbnail_filename = generate_thumbnail(full_video_path, THUMBNAIL_DIR)
            
            if thumbnail_filename:
                session.thumbnail_path = thumbnail_filename
                db.commit()
            
            db.commit()
    except Exception as e:
        session = db.query(DBSession).filter(DBSession.id == session_id).first()
        if session:
            session.status = "failed"
            db.commit()
        print(f"Analysis error: {e}")
    finally:
        db.close()

@app.get("/video-status/{session_id}", response_model=VideoStatusResponse)
async def get_video_status(
    session_id: int,
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    session = db.query(DBSession).filter(DBSession.id == session_id, DBSession.user_id == current_user.id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    analysis = db.query(Analysis).filter(Analysis.session_id == session_id).first()
    
    return VideoStatusResponse(
        session_id=session_id,
        status=session.status,
        progress=1.0 if session.status == "completed" else 0.5,
        analysis={k: v for k, v in analysis.__dict__.items() if not k.startswith('_')} if analysis else None
    )

# ============== ANALYSIS ROUTES ==============
@app.get("/analysis/{session_id}", response_model=AnalysisResponse)
async def get_analysis(
    session_id: int,
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    session = db.query(DBSession).filter(DBSession.id == session_id, DBSession.user_id == current_user.id).first()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    analysis = db.query(Analysis).filter(Analysis.session_id == session_id).first()
    if not analysis:
        raise HTTPException(status_code=404, detail="Analysis not found")
    
    return analysis

# ============== DASHBOARD ROUTES ==============
@app.get("/dashboard", response_model=DashboardStats)
async def get_dashboard(
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    players = db.query(Player).filter(Player.user_id == current_user.id).all()
    sessions = db.query(DBSession).filter(DBSession.user_id == current_user.id).all()
    analyses = db.query(Analysis).join(DBSession).filter(DBSession.user_id == current_user.id).all()
    
    total_players = len(players)
    total_sessions = len(sessions)
    total_videos = len([s for s in sessions if s.status == "completed"])
    avg_rating = sum(p.overall_rating for p in players) / len(players) if players else 0
    
    # Top performers
    top_performers = []
    for player in sorted(players, key=lambda p: p.overall_rating, reverse=True)[:5]:
        sessions_data = db.query(DBSession).filter(DBSession.player_id == player.id).all()
        total_distance = 0.0
        max_speeds = []
        for s in sessions_data:
            a = db.query(Analysis).filter(Analysis.session_id == s.id).first()
            if a:
                total_distance += a.total_distance or 0
                max_speeds.append(a.max_speed or 0)
        avg_max_speed = sum(max_speeds) / len(max_speeds) if max_speeds else 0.0
        
        top_performers.append({
            "id": player.id,
            "user_id": player.user_id,
            "name": player.name,
            "jersey_number": player.jersey_number,
            "position": player.position,
            "age": player.age,
            "height": player.height,
            "weight": player.weight,
            "dominant_foot": player.dominant_foot,
            "overall_rating": player.overall_rating,
            "speed_score": player.speed_score,
            "technique_score": player.technique_score,
            "stamina_score": player.stamina_score,
            "decision_score": player.decision_score,
            "created_at": player.created_at,
            "session_count": len(sessions_data),
            "total_distance": round(total_distance, 1),
            "avg_max_speed": round(avg_max_speed, 1)
        })
    
    # Recent sessions (last 10)
    recent_sessions = []
    for session in sessions[-10:]:
        analysis = db.query(Analysis).filter(Analysis.session_id == session.id).first()
        player = db.query(Player).filter(Player.id == session.player_id).first()
        recent_sessions.append({
            "id": session.id,
            "player_id": session.player_id,
            "user_id": session.user_id,
            "title": session.title,
            "session_type": session.session_type,
            "date": session.date,
            "duration_seconds": session.duration_seconds,
            "video_path": session.video_path,
            "thumbnail_path": session.thumbnail_path,
            "status": session.status,
            "analysis": {k: v for k, v in analysis.__dict__.items() if not k.startswith('_')} if analysis else None,
            "player_name": player.name if player else None
        })
    
    # Weekly activity (last 8 weeks)
    weekly_activity = []
    for i in range(7, -1, -1):
        week_start = datetime.utcnow() - timedelta(weeks=i)
        week_sessions = [s for s in sessions if s.date >= week_start and s.date < week_start + timedelta(weeks=1)]
        weekly_activity.append({
            "week": week_start.strftime("%W"),
            "sessions": len(week_sessions),
            "videos": len([s for s in week_sessions if s.status == "completed"])
        })
    
    # Skill distribution
    skill_distribution = {
        "elite": len([p for p in players if p.overall_rating >= 85]),
        "advanced": len([p for p in players if 70 <= p.overall_rating < 85]),
        "intermediate": len([p for p in players if 50 <= p.overall_rating < 70]),
        "beginner": len([p for p in players if p.overall_rating < 50])
    }
    
    return DashboardStats(
        total_players=total_players,
        total_sessions=total_sessions,
        total_videos_analyzed=total_videos,
        avg_overall_rating=round(avg_rating, 1),
        top_performers=top_performers,
        recent_sessions=recent_sessions,
        weekly_activity=weekly_activity,
        skill_distribution=skill_distribution
    )

@app.get("/performance-trends/{player_id}", response_model=PerformanceTrend)
async def get_performance_trends(
    player_id: int,
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    player = db.query(Player).filter(Player.id == player_id, Player.user_id == current_user.id).first()
    if not player:
        raise HTTPException(status_code=404, detail="Player not found")
    
    sessions = db.query(DBSession).filter(
        DBSession.player_id == player_id,
        DBSession.status == "completed"
    ).order_by(DBSession.date).all()
    
    dates = []
    overall_scores = []
    physical_scores = []
    technique_scores = []
    
    for session in sessions:
        analysis = db.query(Analysis).filter(Analysis.session_id == session.id).first()
        if analysis:
            dates.append(session.date.strftime("%Y-%m-%d"))
            overall_scores.append(analysis.overall_score or 0)
            physical_scores.append(analysis.physical_score or 0)
            technique_scores.append((analysis.dribbling_score + analysis.passing_score) / 2 if analysis.dribbling_score else 0)
    
    return PerformanceTrend(
        player_id=player_id,
        player_name=player.name,
        dates=dates,
        overall_scores=overall_scores,
        physical_scores=physical_scores,
        technique_scores=technique_scores
    )

# ============== DRILL TEMPLATES ==============
@app.get("/drills", response_model=List[DrillTemplateResponse])
async def get_drills(
    category: Optional[str] = None,
    difficulty: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = db.query(DrillTemplate)
    if category:
        query = query.filter(DrillTemplate.category == category)
    if difficulty:
        query = query.filter(DrillTemplate.difficulty == difficulty)
    return query.all()

@app.post("/drills", response_model=DrillTemplateResponse)
async def create_drill(
    drill: DrillTemplateBase,
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    db_drill = DrillTemplate(**drill.dict())
    db.add(db_drill)
    db.commit()
    db.refresh(db_drill)
    return db_drill

# ============== AI COACHING CHAT ==============
@app.post("/ai-feedback", response_model=AIFeedbackResponse)
async def get_ai_feedback(
    request: AIFeedbackRequest,
    db: Session = Depends(get_db),
    current_user: DBUser = Depends(get_current_active_user)
):
    session = db.query(DBSession).filter(
        DBSession.id == request.session_id,
        DBSession.user_id == current_user.id
    ).first()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    analysis = db.query(Analysis).filter(Analysis.session_id == request.session_id).first()
    if not analysis:
        return AIFeedbackResponse(
            answer="Analysis is still processing. Please check back in a few minutes.",
            related_moments=[],
            suggested_drills=[]
        )
    
    # Simple rule-based AI response (in production, use LLM API)
    question = request.question.lower()
    
    if "speed" in question or "sprint" in question or "fast" in question:
        answer = f"Based on this session, your max speed was {analysis.max_speed} km/h. "
        if analysis.max_speed > 30:
            answer += "That's excellent! You're in the top tier for speed. To maintain it, focus on plyometric training twice a week."
        elif analysis.max_speed > 25:
            answer += "Good speed. To improve, add resisted sprints and hill runs to your training."
        else:
            answer += "There's room for improvement. Try 4x30m sprints with full recovery, twice weekly."
        suggested_drills = ["Resisted Sprints", "Hill Runs", "Plyometric Box Jumps"]
    
    elif "shoot" in question or "finish" in question or "goal" in question:
        answer = f"You had {analysis.shot_count} shots in this session with a shooting score of {analysis.shooting_score}/100. "
        if analysis.shooting_score > 75:
            answer += "Good technique! Work on shooting under pressure with limited touches."
        else:
            answer += "Focus on plant foot placement and follow-through. Practice 50 reps per foot daily from various angles."
        suggested_drills = ["Shooting Technique Ladder", "1-Touch Finishing", "Pressure Shooting"]
    
    elif "pass" in question or "passing" in question:
        answer = f"You completed {analysis.pass_count} passes with a passing score of {analysis.passing_score}/100. "
        if analysis.passing_score > 80:
            answer += "Excellent distribution! Try increasing your pass range and weight variety."
        else:
            answer += "Work on weight transfer and body orientation. Practice passing with both feet against a wall."
        suggested_drills = ["Wall Passing", "Weight Transfer Passing", "Long Range Passing"]
    
    elif "strength" in question or "good" in question or "best" in question:
        strengths = analysis.strengths or ["Solid work rate and movement"]
        answer = "Your key strengths from this session: " + "; ".join(strengths[:3]) + ". Keep building on these!"
        suggested_drills = ["Confidence Building Drills", "Match Simulation"]
    
    elif "weak" in question or "improve" in question or "bad" in question:
        weaknesses = analysis.weaknesses or ["Continue developing all areas"]
        recommendations = analysis.recommendations or ["Consistent practice is key"]
        answer = "Areas to improve: " + "; ".join(weaknesses[:3]) + ". " + "Recommendations: " + "; ".join(recommendations[:3])
        suggested_drills = analysis.recommendations[:3] if analysis.recommendations else ["Fundamental Skill Work"]
    
    else:
        answer = f"Overall, you scored {analysis.overall_score}/100 in this session. "
        answer += "Your physical score was particularly strong. Continue filming every session to track progress!"
        suggested_drills = ["Session Recording", "Self-Review Analysis", "Progressive Drills"]
    
    # Get related moments
    related_moments = []
    if "speed" in question:
        related_moments = [m for m in (analysis.key_moments or []) if m.get("type") == "sprint"][:3]
    elif "shoot" in question:
        related_moments = [m for m in (analysis.key_moments or []) if m.get("type") == "shot"][:3]
    elif "pass" in question:
        related_moments = [m for m in (analysis.key_moments or []) if m.get("type") == "pass"][:3]
    
    return AIFeedbackResponse(
        answer=answer,
        related_moments=related_moments,
        suggested_drills=suggested_drills
    )

# ============== SEED DATA ==============
@app.post("/seed")
async def seed_data(db: Session = Depends(get_db)):
    """Seed demo data for testing."""
    # Check if data exists
    if db.query(DrillTemplate).first():
        return {"message": "Data already seeded"}
    
    # Seed drill templates
    drills = [
        DrillTemplate(
            name="Speed Ladder Drills",
            description="Improve foot speed and coordination through ladder patterns",
            category="physical",
            difficulty="beginner",
            duration_minutes=15,
            target_metrics=["speed", "agility", "coordination"],
            instructions=[
                "Place speed ladder on flat ground",
                "Run through with one foot in each square",
                "Progress to two feet in each square",
                "Add lateral movements and backwards runs"
            ]
        ),
        DrillTemplate(
            name="1v1 Dribbling Gates",
            description="Beat defenders through cone gates with ball control",
            category="technical",
            difficulty="intermediate",
            duration_minutes=20,
            target_metrics=["dribbling", "close_control", "decision_making"],
            instructions=[
                "Set up 5 cone gates 2m apart",
                "Dribble through each gate using both feet",
                "Add passive defender after 3 rounds",
                "Time each run and try to beat your record"
            ]
        ),
        DrillTemplate(
            name="Passing Triangle",
            description="Passing accuracy and first-touch control in groups of 3",
            category="technical",
            difficulty="beginner",
            duration_minutes=15,
            target_metrics=["passing", "first_touch", "movement"],
            instructions=[
                "Form a triangle with 10m sides",
                "Pass and move to the next cone",
                "Use one-touch when possible",
                "Receive across your body, open to the field"
            ]
        ),
        DrillTemplate(
            name="Finishing Under Pressure",
            description="Shoot with limited touches after receiving from various angles",
            category="technical",
            difficulty="advanced",
            duration_minutes=25,
            target_metrics=["shooting", "composure", "technique"],
            instructions=[
                "Set up with server and goalkeeper",
                "Receive pass, take 1 touch max, shoot",
                "Vary angles: straight, wide, cut-back",
                "Focus on placement over power"
            ]
        ),
        DrillTemplate(
            name="Small-Sided Game (4v4)",
            description="Tactical development in tight spaces with high repetition",
            category="tactical",
            difficulty="intermediate",
            duration_minutes=30,
            target_metrics=["decision_making", "positioning", "teamwork"],
            instructions=[
                "Play 4v4 on 30x20m pitch",
                "3-touch maximum per player",
                "Focus on quick transitions",
                "Rotate positions every 5 minutes"
            ]
        ),
        DrillTemplate(
            name="Plyometric Circuit",
            description="Explosive power development for jumping and sprinting",
            category="physical",
            difficulty="advanced",
            duration_minutes=20,
            target_metrics=["power", "explosiveness", "injury_prevention"],
            instructions=[
                "Box jumps: 3 sets of 8 reps",
                "Bounding: 3 sets of 20m",
                "Single-leg hops: 3 sets of 10 each leg",
                "Rest 90 seconds between sets"
            ]
        ),
        DrillTemplate(
            name="Scanning and Awareness",
            description="Train visual awareness before receiving the ball",
            category="mental",
            difficulty="intermediate",
            duration_minutes=15,
            target_metrics=["awareness", "scanning", "decision_making"],
            instructions=[
                "Set up with colored cones around player",
                "Call color before receiving pass",
                "Player must scan and identify color",
                "Progress to calling 2 colors for sequence"
            ]
        ),
        DrillTemplate(
            name="Crossing and Finishing",
            description="Wide players cross, attackers finish with various techniques",
            category="technical",
            difficulty="intermediate",
            duration_minutes=25,
            target_metrics=["crossing", "finishing", "timing"],
            instructions=[
                "Wide player dribbles to byline",
                "Cross from different positions",
                "Attackers make varied runs",
                "Finish with 1 touch, 2 touch, header, volley"
            ]
        )
    ]
    
    for drill in drills:
        db.add(drill)
    
    db.commit()
    return {"message": "Demo data seeded successfully"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
